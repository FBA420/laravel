<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('interviews', function (Blueprint $table) {
            $table->id('id');
            $table->text('heading');
            $table->text('subheading1');
            $table->text('paragraph1');
            $table->string('image1')->nullable();
            $table->text('subheading2')->nullable();
            $table->text('paragraph2')->nullable();
            $table->string('image2')->nullable();
            $table->text('subheading3')->nullable();
            $table->text('paragraph3')->nullable();
            $table->string('image3')->nullable();
            $table->text('subheading4')->nullable();
            $table->text('paragraph4')->nullable();
            $table->string('image4')->nullable();
            $table->text('subheading5')->nullable();
            $table->text('paragraph5')->nullable();
            $table->string('image5')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('interviews');
    }
};
