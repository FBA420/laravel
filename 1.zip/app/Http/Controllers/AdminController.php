<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use App\Models\Joboffer;
use App\Models\Joboffer2;
use App\Models\Joboffer3;
use App\Models\Usercv;
use App\Models\Contact;

class AdminController extends Controller
{
  public function user(){
    if (Auth::id() == '2') {
      $data = User::all();
      return view("admin.userdata",compact('data'));
  } else {
      return redirect('/login');
  }
}
public function deleteuser($id){
  if (Auth::id() == '2') {
    $data = User::find($id);
    $data->delete();
    return redirect()->back();
  } else {
    return redirect('/login');
}
}

public function contact(){
  if (Auth::id() == '2') {
  $data = Contact::all();
  return view("admin.admincontact",compact('data'));
} else {
  return redirect('/login');
}
}
public function deletecontact($id){
  if (Auth::id() == '2') {
  $data = Contact::find($id);
  $data->delete();
  return redirect()->back();
} else {
  return redirect('/login');
}
}
public function cvdata(){
  if (Auth::id() == '2') {
  $data =  Usercv::all();
return view("admin.cvdata",compact('data'));
} else {
  return redirect('/login');
}
}
public function deletecvdata($id){
  if (Auth::id() == '2') {
  $data = Usercv::find($id);
  $data->delete();
  return redirect()->back();
} else {
  return redirect('/login');
}
}
public function joboffer(){
  if (Auth::id() == '2') {
  $data =  Joboffer::all();
return view("admin.joboffer",compact('data'));
} else {
  return redirect('/login');
}
}
public function deletejoboffer($id){
  if (Auth::id() == '2') {
  $data = Joboffer::find($id);
  $data->delete();
  return redirect()->back();
} else {
  return redirect('/login');
}
}
public function tenders(){
  if (Auth::id() == '2') {
  $data =  Joboffer2::all();
return view("admin.tender",compact('data'));
} else {
  return redirect('/login');
}
}
public function deletetenders($id){
  if (Auth::id() == '2') {
  $data = Joboffer2::find($id);
  $data->delete();
  return redirect()->back();
} else {
  return redirect('/login');
}
}
public function review(){
  if (Auth::id() == '2') {
  $data =  Joboffer3::all();
return view("admin.review",compact('data'));
} else {
  return redirect('/login');
}
}
public function deletereview($id){
  if (Auth::id() == '2') {
  $data = Joboffer3::find($id);
  $data->delete();
  return redirect()->back();
} else {
  return redirect('/login');
}
}

}
