<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Joboffer;
use App\Models\Joboffer2;
use App\Models\Joboffer3;
use App\Models\Usercv;
use App\Models\Interview;
use App\Models\Information;
use App\Models\Footer;
use App\Models\Header;
use App\Models\Cvimages;
use App\Models\Advertisment;


class HomeController extends Controller
{
   public function index(){
    $data = Joboffer::all();
    $data1 = Joboffer2::all();
    $data2 = Joboffer3::all();
    $data3 = Cvimages::all();
    $head = Header::all();
    $ade = Advertisment::all();

    
    $foot1 = Footer::whereIn('id', [1])->get();
    $foot2 = Footer::whereIn('id', [1, 2, 3, 4, 5, 6])->get();
    $foot3 = Footer::whereIn('id', [7, 8, 9, 10, 11, 12])->get();
    return view('home',compact('data','data1','data2','data3','foot1','foot2','foot3','head','ade'));
   }
   public function redirects(){

    $usertype = Auth::user()->usertype;
    $data = Joboffer::all();
    $data1 = Joboffer2::all();
    $data2 = Joboffer3::all();
    $data3 = Cvimages::all();
    $head = Header::all();
    $ade = Advertisment::all();

    $foot1 = Footer::whereIn('id', [1])->get();
    $foot2 = Footer::whereIn('id', [1, 2, 3, 4, 5, 6])->get();
    $foot3 = Footer::whereIn('id', [7, 8, 9, 10, 11, 12])->get();

    if($usertype=='1'){
        return view('admin.adminhome');
    } else{ 
        return view('home',compact('data','data1','data2','data3','foot1','foot2','foot3','head','ade'));

    }
   }
   public function cv(){
    $data3 = Usercv::all();
    $head = Header::all();
    return view('cv',compact('data3','head'));
   }
   public function letter(){
    $head = Header::all();
    $data3 = Usercv::all();
    return view('coverletter',compact('data3','head'));
   }
   public function inter(){
    $head = Header::all();
    $data = Interview::all();
    return view('inter',compact('data','head'));
   }
    
    public function contactpage(){
        $head = Header::all();
    $data = Information::all();
    return view('contact',compact('data','head'));
    }

    public function jobform1(){
        $head = Header::all();
        return view('jobform1',compact('head'));
        }
    
        public function jobform2(){
            $head = Header::all();
            return view('jobform2',compact('head'));
        }
            
    public function jobform3(){
        $head = Header::all();
        return view('jobform3',compact('head'));
        }
        public function cvform(){
            if(Auth::id()){
                $head = Header::all();
                return view('cvform',compact('head'));
            }
            else{
                return redirect('/login');
            }
        }
        public function solution(){
           $head = Header::all();
            return view('solution',compact('head'));
        }
        public function discription($id)
        {
            $head = Header::all();
            $data = Joboffer::find($id);
            $data->views += 1;
            $data->save();
            return view('discrip_show', compact('head','data'));
        }     
        public function discription1($id)
        {
            $head = Header::all();
            $data1 = Joboffer2::find($id);
            $data1->views += 1;
            $data1->save();
            return view('discrip_show1', compact('head','data1'));
        }   
        public function discription2($id)
        {
            $head = Header::all();
            $data2 = Joboffer3::find($id);
            $data2->views += 1;
            $data2->save();
            return view('descrip_show2', compact('head','data2'));
        }      
}
