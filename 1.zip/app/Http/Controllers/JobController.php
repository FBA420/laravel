<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Response;
use Illuminate\Support\Facades\Auth;
use App\Models\Joboffer;
use App\Models\Usercv;
use App\Models\Joboffer2;
use App\Models\Joboffer3;
use Illuminate\Support\Facades\Session;
use App\Models\Contact;

class JobController extends Controller
{
        public function joboffer1(Request $request){
            $data = new Joboffer();

            $data->company = $request->company;
            $data->city = $request->city;
            $data->deadline = $request->deadline;
            $data->title = $request->title;
            $data->description = $request->description;
            $data->domain = $request->domaine;
            $data->qualification = $request->qualification;
            $data->experience = $request->experience;
            if($request->hasFile('logo')){
                $file = $request->file('logo');
                $extention = $file->getClientOriginalExtension();
                $filename = time().'.'.$extention;
                $file->move('images/',$filename);
                $data->logo = $filename;
               }
               if($request->hasFile('file')){
                $file = $request->file('file');
                $extention = $file->getClientOriginalExtension();
                $filename = time().'.'.$extention;
                $file->move('pdffiles/',$filename);
                $data->file = $filename;
               }
            $data->save();
            Session::flash('success', 'Form submitted successfully!!!');
            return redirect()->back();
        }
      

        public function joboffer2(Request $request){
        
            $data = new Joboffer2();
    
            $data->company = $request->company;
            $data->city = $request->city;
            $data->deadline = $request->deadline;
            $data->title = $request->title;
            $data->description = $request->description;
            if($request->hasFile('logo')){
                $file = $request->file('logo');
                $extention = $file->getClientOriginalExtension();
                $filename = time().'.'.$extention;
                $file->move('images/',$filename);
                $data->logo = $filename;
               }
               if($request->hasFile('file')){
                $file = $request->file('file');
                $extention = $file->getClientOriginalExtension();
                $filename = time().'.'.$extention;
                $file->move('pdffiles/',$filename);
                $data->file = $filename;
               }
            $data->save();
            Session::flash('success', 'Form submitted successfully!!!');

            return redirect()->back();
        }


        public function joboffer3(Request $request){
        
            $data = new Joboffer3();
    
            $data->company = $request->company;
            $data->deadline = $request->deadline;
            $data->title = $request->title;
            $data->description = $request->description;
            if($request->hasFile('logo')){
                $file = $request->file('logo');
                $extention = $file->getClientOriginalExtension();
                $filename = time().'.'.$extention;
                $file->move('images/',$filename);
                $data->logo = $filename;
               }
               if($request->hasFile('file')){
                $file = $request->file('file');
                $extention = $file->getClientOriginalExtension();
                $filename = time().'.'.$extention;
                $file->move('pdffiles/',$filename);
                $data->file = $filename;
               }
            $data->save();
            Session::flash('success', 'Form submitted successfully!!!');
            return redirect()->back();
        }
        public function usercvs(Request $request){
        
            $data = new Usercv();
    
            $data->name = $request->name;
            $data->contact = $request->contact;
            $data->qualification = $request->qualification;
            $data->field = $request->field;
            $data->age = $request->age;
            $data->cvfile = $request->qualification;
            $data->cvimage = $request->experience;
            $data->letter = $request->experience;
            if($request->hasFile('image')){
                $file = $request->file('image');
                $extention = $file->getClientOriginalExtension();
                $filename = time().'.'.$extention;
                $file->move('images/',$filename);
                $data->image = $filename;
               }
               if($request->hasFile('cvfile')){
                $file = $request->file('cvfile');
                $extention = $file->getClientOriginalExtension();
                $filename = time().'.'.$extention;
                $file->move('pdffiles/',$filename);
                $data->cvfile = $filename;
               }
               if($request->hasFile('cvpic')){
                $file = $request->file('cvpic');
                $extention = $file->getClientOriginalExtension();
                $filename = time().'.'.$extention;
                $file->move('pdffiles/',$filename);
                $data->cvimage = $filename;
               }
               if($request->hasFile('letter')){
                $file = $request->file('letter');
                $extention = $file->getClientOriginalExtension();
                $filename = time().'.'.$extention;
                $file->move('pdffiles/',$filename);
                $data->letter = $filename;
               }
            $data->save();
            Session::flash('success', 'Form submitted successfully!!!');
            return redirect()->back();
        }
        public function contact(Request $request){   
            $data = new Contact();
            $data->name = $request->name;
            $data->email = $request->email;
            $data->subject = $request->subject;
            $data->message = $request->message;
            $data->captcha = $request->captcha;
            $data->save();
            Session::flash('success', 'Form submitted successfully!!!');
            return redirect()->back();
        }

    
    }

