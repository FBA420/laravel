<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Interview;
use App\Models\Information;
use App\Models\Footer;
use App\Models\Header;
use App\Models\Cvimages;
use App\Models\Advertisment;

class InterviewController extends Controller
{
    public function interview(){
  if (Auth::id() == '2') {
        $data= Interview::all();
        return view("admin.interview",compact('data'));
      } else {
         return redirect('/login');
       }

   }
   public function uploadinterview(Request $request){
  if (Auth::id() == '2') {
       $data = new Interview;
       $data->heading = $request->heading;
       $data->subheading1 = $request->head1;
       $data->paragraph1 = $request->para1;
       $data->subheading2 = $request->head2;
       $data->paragraph2 = $request->para2;
       $data->subheading3 = $request->head3;
       $data->paragraph3 = $request->para3;
       $data->subheading4 = $request->head4;
       $data->paragraph4 = $request->para4;       
       $data->subheading5 = $request->head5;
       $data->paragraph5 = $request->para5;
       if($request->hasFile('img1')){
           $file = $request->file('img1');
           $extention = $file->getClientOriginalExtension();
           $filename = time().'.'.$extention;
           $file->move('images/',$filename);
           $data->image1 = $filename;
          }
          if($request->hasFile('img2')){
            $file = $request->file('img2');
            $extention = $file->getClientOriginalExtension();
            $filename = time().'.'.$extention;
            $file->move('images/',$filename);
            $data->image2 = $filename;
           }
           if($request->hasFile('img3')){
            $file = $request->file('img3');
            $extention = $file->getClientOriginalExtension();
            $filename = time().'.'.$extention;
            $file->move('images/',$filename);
            $data->image3 = $filename;
           }
           if($request->hasFile('img4')){
            $file = $request->file('img4');
            $extention = $file->getClientOriginalExtension();
            $filename = time().'.'.$extention;
            $file->move('images/',$filename);
            $data->image4 = $filename;
           }
           if($request->hasFile('img5')){
            $file = $request->file('img5');
            $extention = $file->getClientOriginalExtension();
            $filename = time().'.'.$extention;
            $file->move('images/',$filename);
            $data->image5 = $filename;
           }
       $data->save();
       return redirect()->back();
      } else {
         return redirect('/login');
       }
   }
   
   public function updateinterview($id){
  if (Auth::id() == '2') {
       $data = Interview::find($id);
       return view("admin.updateinterview",compact('data'));
      } else {
         return redirect('/login');
       }
   }
   public function editInterview(Request $request , $id){
  if (Auth::id() == '2') {
       $data = Interview::find($id);
       $data->heading = $request->heading;
       $data->subheading1 = $request->head1;
       $data->paragraph1 = $request->para1;
       $data->subheading2 = $request->head2;
       $data->paragraph2 = $request->para2;
       $data->subheading3 = $request->head3;
       $data->paragraph3 = $request->para3;
       $data->subheading4 = $request->head4;
       $data->paragraph4 = $request->para4;       
       $data->subheading5 = $request->head5;
       $data->paragraph5 = $request->para5;
       if($request->hasFile('img1')){
           $file = $request->file('img1');
           $extention = $file->getClientOriginalExtension();
           $filename = time().'.'.$extention;
           $file->move('images/',$filename);
           $data->image1 = $filename;
          }
          if($request->hasFile('img2')){
            $file = $request->file('img2');
            $extention = $file->getClientOriginalExtension();
            $filename = time().'.'.$extention;
            $file->move('images/',$filename);
            $data->image2 = $filename;
           }
           if($request->hasFile('img3')){
            $file = $request->file('img3');
            $extention = $file->getClientOriginalExtension();
            $filename = time().'.'.$extention;
            $file->move('images/',$filename);
            $data->image3 = $filename;
           }
           if($request->hasFile('img4')){
            $file = $request->file('img4');
            $extention = $file->getClientOriginalExtension();
            $filename = time().'.'.$extention;
            $file->move('images/',$filename);
            $data->image4 = $filename;
           }
           if($request->hasFile('img5')){
            $file = $request->file('img5');
            $extention = $file->getClientOriginalExtension();
            $filename = time().'.'.$extention;
            $file->move('images/',$filename);
            $data->image5 = $filename;
           }
       $data->save();
       return redirect()->back();
      } else {
         return redirect('/login');
       }
   }
       public function deleteinterview($id){
         if (Auth::id() == '2') {
       $data = Interview::find($id);
       $data->delete();
       return redirect()->back();
      } else {
         return redirect('/login');
       }
   }

   public function information(){
  if (Auth::id() == '2') {
      
    $data= Information::all();
    
    return view("admin.information",compact('data'));
   } else {
      return redirect('/login');
    }

}
public function uploadinformation(Request $request){
  if (Auth::id() == '2') {
   $data = new Information;
   $data->address = $request->address;
   $data->contact = $request->phone;
   $data->mail = $request->email;
   $data->heading = $request->heading;
   $data->name = $request->name;
   $data->save();
   return redirect()->back();
} else {
   return redirect('/login');
 }
}

public function updateinformation($id){
  if (Auth::id() == '2') {

   $data = Information::find($id);
   return view("admin.updateinformation",compact('data'));
} else {
   return redirect('/login');
 }
}
public function editinformation(Request $request , $id){
  if (Auth::id() == '2') {

   $data = Information::find($id);
   $data->address = $request->address;
   $data->contact = $request->phone;
   $data->mail = $request->email;
   $data->heading = $request->heading;
   $data->name = $request->name;
   $data->save();
   return redirect()->back();
} else {
   return redirect('/login');
 }
}
   public function deleteinformation($id){
  if (Auth::id() == '2') {

   $data = Information::find($id);
   $data->delete();
   return redirect()->back();
} else {
   return redirect('/login');
 }
}
public function cvpic(){
  if (Auth::id() == '2') {

    $data= Cvimages::all();
    return view("admin.addcvpic",compact('data'));
   } else {
      return redirect('/login');
    }
}
public function uploadcvpic(Request $request){
  if (Auth::id() == '2') {

   $data = new Cvimages;
    if($request->hasFile('image')){
    $file = $request->file('image');
    $extention = $file->getClientOriginalExtension();
    $filename = time().'.'.$extention;
    $file->move('images/',$filename);
    $data->image = $filename;
   }
   $data->save();
   return redirect()->back();
} else {
   return redirect('/login');
 }
}

public function updatecvpic($id){
  if (Auth::id() == '2') {
   $data = Cvimages::find($id);
   return view("admin.updatecvpic",compact('data'));
} else {
   return redirect('/login');
 }
}
public function editcvpic(Request $request , $id){
   if (Auth::id() == '2') {
   $data = Cvimages::find($id);
   if($request->hasFile('image')){
   $file = $request->file('image');
   $extention = $file->getClientOriginalExtension();
   $filename = time().'.'.$extention;
   $file->move('images/',$filename);
   $data->image = $filename;
  }
   $data->save();
   return redirect()->back();
} else {
   return redirect('/login');
 }
}
   public function deletecvpic($id){
      if (Auth::id() == '2') {
   $data = Cvimages::find($id);
   $data->delete();
   return redirect()->back();
} else {
   return redirect('/login');
 }
}


public function footer(){
  if (Auth::id() == '2') {
    $data= Footer::all();
    return view("admin.adfooter",compact('data'));
   } else {
      return redirect('/login');
    }
}
public function uploadfooter(Request $request){
   if (Auth::id() == '2') {
   $data = new Footer;
   $data->copyright = $request->copyright;
    if($request->hasFile('image')){
    $file = $request->file('image');
    $extention = $file->getClientOriginalExtension();
    $filename = time().'.'.$extention;
    $file->move('images/',$filename);
    $data->image = $filename;
   }
   $data->save();
   return redirect()->back();
} else {
   return redirect('/login');
 }
}

public function updatefooter($id){
   if (Auth::id() == '2') {
   $data = Footer::find($id);
   return view("admin.updatefooter",compact('data'));
} else {
   return redirect('/login');
 }
}
public function editfooter(Request $request , $id){
   if (Auth::id() == '2') {
   $data = Footer::find($id);
   $data->copyright = $request->copyright;
   if($request->hasFile('image')){
   $file = $request->file('image');
   $extention = $file->getClientOriginalExtension();
   $filename = time().'.'.$extention;
   $file->move('images/',$filename);
   $data->image = $filename;
  }
   $data->save();
   return redirect()->back();
} else {
   return redirect('/login');
 }
}
   public function deletefooter($id){
      if (Auth::id() == '2') {
   $data = Footer::find($id);
   $data->delete();
   return redirect()->back();
} else {
   return redirect('/login');
 }
}

public function header(){
  if (Auth::id() == '2') {
    $data= Header::all();
    return view("admin.adheader",compact('data'));
   } else {
      return redirect('/login');
    }

}
public function uploadheader(Request $request){
   if (Auth::id() == '2') {
   $data = new Header;
    if($request->hasFile('logo')){
    $file = $request->file('logo');
    $extention = $file->getClientOriginalExtension();
    $filename = time().'.'.$extention;
    $file->move('images/',$filename);
    $data->logo = $filename;
   }
   if($request->hasFile('add')){
    $file = $request->file('add');
    $extention = $file->getClientOriginalExtension();
    $filename = time().'.'.$extention;
    $file->move('images/',$filename);
    $data->add = $filename;
   }
   $data->save();
   return redirect()->back();
} else {
   return redirect('/login');
 }
}

public function updateheader($id){
   if (Auth::id() == '2') {
   $data = Header::find($id);
   return view("admin.updateheader",compact('data'));
} else {
   return redirect('/login');
 }
}
public function editheader(Request $request , $id){
   if (Auth::id() == '2') {
   $data = Header::find($id);
   if($request->hasFile('logo')){
    $file = $request->file('logo');
    $extention = $file->getClientOriginalExtension();
    $filename = time().'.'.$extention;
    $file->move('images/',$filename);
    $data->logo = $filename;
   }
   if($request->hasFile('add')){
    $file = $request->file('add');
    $extention = $file->getClientOriginalExtension();
    $filename = time().'.'.$extention;
    $file->move('images/',$filename);
    $data->add = $filename;
   }
   $data->save();
   return redirect()->back();
} else {
   return redirect('/login');
 }
}
   public function deleteheader($id){
      if (Auth::id() == '2') {
   $data = Header::find($id);
   $data->delete();
   return redirect()->back();
} else {
   return redirect('/login');
 }
}


public function advertisement(){

  if (Auth::id() == '2') {

   $data= Advertisment::all();
   return view("admin.advertisment",compact('data'));
} else {
   return redirect('/login');
 }

}
public function uploadadvertisement(Request $request){
   if (Auth::id() == '2') {
  $data = new Advertisment;
   if($request->hasFile('image')){
   $file = $request->file('image');
   $extention = $file->getClientOriginalExtension();
   $filename = time().'.'.$extention;
   $file->move('images/',$filename);
   $data->image = $filename;
  }
  $data->save();
  return redirect()->back();
} else {
   return redirect('/login');
 }
}

public function updateadvertisement($id){
   if (Auth::id() == '2') {
  $data = Advertisment::find($id);
  return view("admin.updateadvertisement",compact('data'));
} else {
   return redirect('/login');
 }
}
public function editadvertisement(Request $request , $id){
   if (Auth::id() == '2') {
  $data = Advertisment::find($id);
  if($request->hasFile('image')){
  $file = $request->file('image');
  $extention = $file->getClientOriginalExtension();
  $filename = time().'.'.$extention;
  $file->move('images/',$filename);
  $data->image = $filename;
 }
  $data->save();
  return redirect()->back();
} else {
   return redirect('/login');
 }
}
  public function deleteadvertisement($id){
   if (Auth::id() == '2') {
  $data = Advertisment::find($id);
  $data->delete();
  return redirect()->back();
} else {
   return redirect('/login');
 }
}
}

