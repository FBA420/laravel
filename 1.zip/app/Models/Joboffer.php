<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Http\Controllers\JobController;

class Joboffer extends Model
{
    use HasFactory;
    protected $table = 'joboffers';
    protected $fillable = [
       'company',
       'logo',
       'city',
       'deadline',
       'title',
       'description',
       'domain',
       'qualification',
       'experience',
       'file',
       'views',
    ];
}
