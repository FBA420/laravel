<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Http\Controllers\JobController;

class Joboffer3 extends Model
{
    use HasFactory;
    protected $table = 'joboffer3s';
    protected $fillable = [
       'company',
       'logo',
       'deadline',
       'title',
       'description',
       'file',
       'views'
    ];
}
