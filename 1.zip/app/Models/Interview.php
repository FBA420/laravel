<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Http\Controllers\InterviewController;

class Interview extends Model
{
    use HasFactory;
    protected $table = 'interviews';
    protected $fillable = [
       'heading',
       'subheading1',
       'paragraph1',
       'image1',
       'subheading2',
       'paragraph2',
       'image2',
       'subheading3',
       'paragraph3',
       'image3',
       'subheading4',
       'paragraph4',
       'image4',
       'subheading5',
       'paragraph5',
       'image5',
    ];
}
