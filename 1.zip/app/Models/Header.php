<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Http\Controllers\InterviewController;

class Header extends Model
{
    use HasFactory;
    protected $table = 'headers';
    protected $fillable = [
      'logo',
      'add',
    ];
}
