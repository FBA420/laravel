<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Session;
use App\Http\Controllers\JobController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\InterviewController;
use App\Http\Controllers\AdminController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/users', [AdminController::class, 'user']);
Route::get('/contact', [AdminController::class, 'contact']);
Route::get('/deletecontact/{id}',[AdminController::class,'deletecontact']);
Route::get('/deleteuser/{id}',[AdminController::class,'deleteuser']);
Route::get('/cvdata', [AdminController::class, 'cvdata']);
Route::get('/deletecvdata/{id}',[AdminController::class,'deletecvdata']);
Route::get('/joboffer', [AdminController::class, 'joboffer']);
Route::get('/deletejoboffer/{id}',[AdminController::class,'deletejoboffer']);
Route::get('/tenders', [AdminController::class, 'tenders']);
Route::get('/deletetenders/{id}',[AdminController::class,'deletetenders']);
Route::get('/review', [AdminController::class, 'review']);
Route::get('/deletereview/{id}',[AdminController::class,'deletereview']);
// Interview section
Route::get('/interview', [InterviewController::class, 'interview']);
Route::post('/uploadinterview',[InterviewController::class,'uploadinterview']);
Route::get('/updateinterview/{id}',[InterviewController::class,'updateinterview']);
Route::post('/editinterview/{id}',[InterviewController::class,'editinterview']);
Route::get('/deleteinterview/{id}',[InterviewController::class,'deleteinterview']);
// contact information
Route::get('/information', [InterviewController::class, 'information']);
Route::post('/uploadinformation',[InterviewController::class,'uploadinformation']);
Route::get('/updateinformation/{id}',[InterviewController::class,'updateinformation']);
Route::post('/editinformation/{id}',[InterviewController::class,'editinformation']);
Route::get('/deleteinformation/{id}',[InterviewController::class,'deleteinformation']);
// footer information
Route::get('/footer', [InterviewController::class, 'footer']);
Route::post('/uploadfooter',[InterviewController::class,'uploadfooter']);
Route::get('/updatefooter/{id}',[InterviewController::class,'updatefooter']);
Route::post('/editfooter/{id}',[InterviewController::class,'editfooter']);
Route::get('/deletefooter/{id}',[InterviewController::class,'deletefooter']);
// header information
Route::get('/header', [InterviewController::class, 'header']);
Route::post('/uploadheader',[InterviewController::class,'uploadheader']);
Route::get('/updateheader/{id}',[InterviewController::class,'updateheader']);
Route::post('/editheader/{id}',[InterviewController::class,'editheader']);
Route::get('/deleteheader/{id}',[InterviewController::class,'deleteheader']);
// Advertisement 
Route::get('/advertisement', [InterviewController::class, 'advertisement']);
Route::post('/uploadadvertisement',[InterviewController::class,'uploadadvertisement']);
Route::get('/updateadvertisement/{id}',[InterviewController::class,'updateadvertisement']);
Route::post('/editadvertisement/{id}',[InterviewController::class,'editadvertisement']);
Route::get('/deleteadvertisement/{id}',[InterviewController::class,'deleteadvertisement']);
// cvpic information
Route::get('/cvpic', [InterviewController::class, 'cvpic']);
Route::post('/uploadcvpic',[InterviewController::class,'uploadcvpic']);
Route::get('/updatecvpic/{id}',[InterviewController::class,'updatecvpic']);
Route::post('/editcvpic/{id}',[InterviewController::class,'editcvpic']);
Route::get('/deletecvpic/{id}',[InterviewController::class,'deletecvpic']);
// Forms
Route::post('/joboffer', [JobController::class, 'joboffer1']);
Route::get('/viewjoboffer', [JobController::class, 'viewjoboffer1']);
Route::post('/cvform', [JobController::class, 'usercvs']);
Route::post('/joboffer2', [JobController::class, 'joboffer2']);
Route::post('/joboffer3', [JobController::class, 'joboffer3']);
Route::post('/contact', [JobController::class, 'contact']);

//Web Pages
Route::get('/redirects', [HomeController::class, 'redirects']);
Route::get('/', [HomeController::class, 'index']);
Route::get('/interview-article', [HomeController::class, 'inter']);
Route::get('/cv', [HomeController::class, 'cv']);
Route::get('/letter', [HomeController::class, 'letter']);
Route::get('/contactpage', [HomeController::class, 'contact']);
Route::get('/job-offer-form', [HomeController::class, 'jobform1']);
Route::get('/tender-form', [HomeController::class, 'jobform2']);
Route::get('/review-form', [HomeController::class, 'jobform3']);
Route::get('/cv-form', [HomeController::class, 'cvform']);
Route::get('/article', [HomeController::class, 'solution']);
Route::get('/contact-form', [HomeController::class, 'contactpage']);
Route::get('/job-description/{id}', [HomeController::class, 'discription']);
Route::get('/tenders-description/{id}', [HomeController::class, 'discription1']);
Route::get('/reviews-description/{id}', [HomeController::class, 'discription2']);


Route::middleware(['auth:sanctum',config('jetstream.auth_session'),'verified'])->group(function () {
    Route::get('/dashboard', function () { return view('dashboard'); })->name('dashboard');
});
Route::get( uri: 'locale/{locale}', action: function ($locale) {
    Session::put( key: 'locale', value: $locale);
    return redirect()->back();
});