
@include('header');
@if (Session::has('success'))
    <div class="alert alert-success text-center">
        {{ Session::get('success') }}
    </div>
@endif
<div class="container">
    <button type="button" disabled="" class="btn btn-dark btn-lg btn-block fontAlmari btn btn-primary"
    style="margin-top: 15px; margin-bottom: 10px; color: rgb(255, 255, 255); width: 100%;">
    {{__('welcome.You can send your opinions about us')}}
    <span style="font-weight: bold;">contact@rimemploi.com</span>
</button>  
          <!-- row having bottom and top lines -->
    <div>
        <p class="fontAlmari" style="border-width: 2px 0px; border-top-style: solid; border-right-style: initial; border-bottom-style: solid; border-left-style: initial; border-color: black; border-image: initial; text-align: center; font-size: 25px; padding: 5px;">
        {{__('welcome.Submit a job offer')}}</p>
    </div>
</div>
<div class="container">
    <form action="{{url('/joboffer')}}" method="post" enctype="multipart/form-data">
 @csrf
<div>
    <div class="row" style="margin: 15px 1px 0px; background: rgb(238, 238, 238); padding-bottom: 10px;">
    <div class="col-sm-4 col-12">
        <label class="fontAlmari form-label">{{__('welcome.Company')}}</label>
        <input required type="text" hidden="" value="0">
        <input required type="text" name="company" class="form-control">
        <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
    </div>
    <div class="col-sm-4 col-12">
        <label class="fontAlmari form-label">{{__('welcome.Logo')}}</label>
        <input required type="file" name="logo"  class="form-control">
    </div>
    <div class="col-sm-4 col-12">
        <label class="fontAlmari form-label">{{__('welcome.City')}}</label>
        <input required type="text" name="city"  class="form-control" value="">
        <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
    </div>
    </div>
    <div class="row" style="margin: 10px 0px 5px;">
<div class="col-sm-9 col-12">
    <label class="fontAlmari form-label">{{__('welcome.Title')}}</label>
    <input required type="text" name="title"  class="form-control">
    <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
</div>
<div class="col-sm-3 col-12">
    <label class="fontAlmari form-label">{{__('welcome.Application deadline')}}</label>
    <input required type="date" name="deadline"  class="form-control">
    <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
</div>

<div class="col-sm-12 col-12">
    <label class="fontAlmari form-label">{{__('welcome.Description')}}</label>
    <textarea class="form-control" name="description" id="" cols="30" rows="10"></textarea>
    <script>
    tinymce.init({
      selector: 'textarea',
      plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount checklist mediaembed casechange export formatpainter pageembed linkchecker a11ychecker tinymcespellchecker permanentpen powerpaste advtable advcode editimage tinycomments tableofcontents footnotes mergetags autocorrect typography inlinecss',
      toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
      tinycomments_mode: 'embedded',
      tinycomments_author: 'Author name',
      mergetags_list: [
        { value: 'First.Name', title: 'First Name' },
        { value: 'Email', title: 'Email' },
      ]
    });
  </script>
    
</div>
<div class="col-sm-12 col-12" style="margin-top: 50px;">
 <div class="row">
 <div class="col-sm-12 col-12" style="margin: 10px 0px 5px;">
 <p class="fontAlmari" style="font-weight: bold; color: black;">{{__('welcome.Other information')}}: </p>
 </div>
 <div class="col-lg-4 col-12">
 <label class="fontAlmari form-label">{{__('welcome.Domain')}}</label>
 <select name="domaine" aria-label="Default select example" class="fontAlmari form-select">
 <option name="domaine" value=""></option>
 <option name="domaine" value="Others">{{__('welcome.Others')}}</option>
 <option name="domaine" value="ressource">{{__('welcome.Human ressources')}}</option>
 <option name="domaine" value="Commercial">{{__('welcome.Commercial, capital-risque, marketing')}}</option>
 <option name="domaine" value="Information">{{__('welcome.Computing and Information Technology')}}</option>
 <option name="domaine" value="transport">{{__('welcome.Logistic transport')}}</option>
 <option name="domaine" value="Maintenance">{{__('welcome.Maintenance and Repair')}}</option>
 <option name="domaine" value="Tourism">{{__('welcome.Tourism, hotels, restaurants')}}</option>
 <option name="domaine" value="Management">{{__('welcome.Management, Finance, Accounting')}}</option>
 <option name="domaine" value="Environment">{{__('welcome.Environment and Sustainable Development')}}</option>
 <option name="domaine" value="Security">{{__('welcome.Security')}}</option>
 <option name="domaine" value="Health">{{__('welcome.Health and social')}}</option>
 <option name="domaine" value="Secretariat">{{__('welcome.Secretariat, assistant')}}</option>
 <option name="domaine" value="Nutrition">{{__('welcome.Nutrition, Breeding, Agriculture')}}</option>
 <option name="domaine" value="Languages">{{__('welcome.Languages, Translation, Literary')}}</option>
 <option name="domaine" value="Electricity_Energy">{{__('welcome.Electricity, Energy, Mechanics, Automation')}}</option>
 <option name="domaine" value="che_bio">{{__('welcome.Chemistry, Biology')}}</option>
 <option name="domaine" value="Civil_Engineering">{{__('welcome.Civil Engineering, Construction')}}</option>
 <option name="domaine" value="Bank">{{__('welcome.Bank and insurance')}}</option>
 </select>
 <p class="fontAlmari" style="font-size: 12px; color: red;">
 </p>
 </div>
 <div class="col-lg-4 col-12">
 <label class="fontAlmari form-label">{{__('welcome.Level of study requested')}}</label>
 <select name="qualification" aria-label="Default select example" class="fontAlmari form-select">
 <option name="qualification" value=""></option>
 <option name="qualification" value="Without">{{__('welcome.Without')}}</option>
 <option name="qualification" value="Primary">{{__('welcome.Primary')}}</option>
 <option name="qualification" value="brevet">{{__('welcome.patent')}}</option>
 <option name="qualification" value="Bac">Bac</option>
 <option name="qualification" value="Bac_2">Bac+2</option>
 <option name="qualification" value="Bac_3">Bac+3</option>
 <option name="qualification" value="Bac_4">Bac+4</option>
 <option name="qualification" value="Bac_5">Bac+5</option>
 <option name="qualification" value="PhD">{{__('welcome.PhD')}}</option>
 <option name="qualification" value="Other">{{__('welcome.Other')}}</option>
 </select>
 <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
 </div>
 <div class="col-lg-4 col-12">
 <label class="fontAlmari form-label">{{__('welcome. Years of Experience')}}</label>
 <select name="experience" aria-label="Default select example" class="fontAlmari form-select">
    <option value=""></option>
    <option name="experience" value="-">-</option>
    <option name="experience" value="0">0</option>
    <option name="experience"  value="1">1</option>
    <option name="experience" value="2">2</option>
    <option name="experience" value="3">3</option>
    <option name="experience" value="4">4</option>
    <option name="experience" value="5">5</option>
    <option name="experience" value="6">6</option>
    <option name="experience" value="7">7</option>
    <option name="experience" value="8">8</option>
    <option name="experience" value="9">9</option>
    <option name="experience" value="10">10</option>
    <option name="experience" value="11">11</option>
    <option name="experience" value="12">12</option>
    <option name="experience" value="13">13</option>
    <option name="experience" value="14">14</option>
    <option name="experience" value="15">15</option>
</select>
<p class="fontAlmari" style="font-size: 12px; color: red;"></p>
</div>
</div>
</div>
</div>
 <table class="table">
    <tbody>
        <tr>
            <td style="width: 100%;">
            <input  type="file" name="file" class="form-control"> 
        </td>

</tr>
</tbody>
</table>
<div style="text-align: center;">
 <button type="submit" value="submit" class="btn btn-success fontAlmari btn btn-primary" style="width: 190px; background: green; color: rgb(255, 255, 255);">{{__('welcome.To validate')}}</button>
    </div>
</div>


    </form>
</div>

@include('footer')
