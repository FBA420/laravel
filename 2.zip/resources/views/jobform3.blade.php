
@include('header');
@if (Session::has('success'))
    <div class="alert alert-success text-center">
        {{ Session::get('success') }}
    </div>
@endif
<div class="container">
    <button type="button" disabled="" class="btn btn-dark btn-lg btn-block fontAlmari btn btn-primary"
    style="margin-top: 15px; margin-bottom: 10px; color: rgb(255, 255, 255); width: 100%;">
    {{__('welcome.You can send your opinions about us')}}
    <span style="font-weight: bold;">contact@rimemploi.com</span>
</button>  
          <!-- row having bottom and top lines -->
    <div>
        <p class="fontAlmari" style="border-width: 2px 0px; border-top-style: solid; border-right-style: initial; border-bottom-style: solid; border-left-style: initial; border-color: black; border-image: initial; text-align: center; font-size: 25px; padding: 5px;">
        {{__('welcome.Leave a review')}}</p>
    </div>
</div>
<div class="container">
    <form action="{{url('joboffer3')}}" method="post" enctype="multipart/form-data">
 @csrf
<div>
    <div class="row" style="margin: 15px 1px 0px; background: rgb(238, 238, 238); padding-bottom: 10px;">
    <div class="col-sm-4 col-12">
        <label class="fontAlmari form-label">{{__('welcome.Company')}}</label>
        <input required type="text" hidden="" value="0">
        <input required type="text" name="company" class="form-control">
        <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
    </div>
    <div class="col-sm-4 col-12">
        <label class="fontAlmari form-label">{{__('welcome.Logo')}}</label>
        <input required type="file" name="logo"  class="form-control">
    </div>
    </div>
    <div class="row" style="margin: 10px 0px 5px;">
<div class="col-sm-9 col-12">
    <label class="fontAlmari form-label">{{__('welcome.Title')}}</label>
    <input required type="text" name="title"  class="form-control">
    <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
</div>
<div class="col-sm-3 col-12">
    <label class="fontAlmari form-label">{{__('welcome.Application deadline')}}</label>
    <input required type="date" name="deadline"  class="form-control">
    <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
</div>

<div class="col-sm-12 col-12">
    <label class="fontAlmari form-label">{{__('welcome.Description')}}</label>
    <textarea class="form-control" name="description" id="" cols="30" rows="10"></textarea>
    <script>
    tinymce.init({
      selector: 'textarea',
      plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount checklist mediaembed casechange export formatpainter pageembed linkchecker a11ychecker tinymcespellchecker permanentpen powerpaste advtable advcode editimage tinycomments tableofcontents footnotes mergetags autocorrect typography inlinecss',
      toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
      tinycomments_mode: 'embedded',
      tinycomments_author: 'Author name',
      mergetags_list: [
        { value: 'First.Name', title: 'First Name' },
        { value: 'Email', title: 'Email' },
      ]
    });
  </script>
    <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
</div>
 <table class="table">
    <tbody>
        <tr>
            <td style="width: 100%;">
            <input  type="file" name="file" class="form-control"> 
        </td>

</tr>
</tbody>
</table>
<div style="text-align: center;">
 <button type="submit" value="submit" class="btn btn-success fontAlmari btn btn-primary" style="width: 190px; background: green; color: rgb(255, 255, 255);">{{__('welcome.To validate')}}</button>
    </div>
</div>


    </form>
</div>
@include('footer')



