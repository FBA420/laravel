@include('header')
</div>
   <div class="container-fluid mt-5">
    <div class="row">
        <div class="col-md-4 mb-3">
            <div class="form-links">
                <a href="/job-offer-form">{{__('welcome.Submit a job offer')}}</a>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="form-links">
                <a href="/cv-form">{{__('welcome.Submit your resume')}}</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-links">
                <a href="/tender-form">{{__('welcome.Submit a call for tenders')}}</a>
            </div>
        </div>
    </div>
   </div>
<div class="home-data-bg">
      <div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
            <div class="data-show">
                <button onclick="showContainer(1)" class="button-link">{{__('welcome.JOB OFFERS')}}</button>
            </div>
        </div>
        <div class="col-md-4">
            <div class="data-show">
                <button onclick="showContainer(2)" class="button-link">{{__('welcome.CALLS FOR TENDERS')}}</button>
            </div>
        </div>
        <div class="col-md-4">
            <div class="data-show">
                <button onclick="showContainer(3)" class="button-link">{{__('welcome.PUBLICATIONS AND NOTICES')}}</button>
            </div>
        </div>
    </div>
   </div>
   <div id="container1" class="data-container job-box">
   <div class="container-fluid">
    <div class="row">
      @foreach ($data as $index => $data)
        <div class="col-md-4 jobs-container">
           <div class="job-offer-div">
              <div class="job-img">
                <img src="/images/{{$data->logo}}" width="100%" height="auto" alt="">
             </div>
             <div class="job-text">
              <a href="{{ url('/job-description', $data->id) }}">{{ $data->title }}</a>
                <div class="job-info">
                    <p><i class="fas fa-map-marker-alt job-l-color"></i> <span class="job-location">{{$data->city}}</span>
                     <i class="fas fa-eye job-l-color eye"></i> <span class="job-views">{{$data->views}}</span>
                   <i class="fas fa-clock fa-spin fa-xs f-clock-color"></i> <span class="job-date f-clock-color">{{$data->deadline}}</span></p>
                </div>
                <div class="container-j">
                    <div class="content">
                      <p><i class="fas fa-building fa-xs f-b-color"></i>{{$data->company}}</p>
                    </div>
                    <div class="button-toggle">
                      <button onclick="toggleContent({{ $index }})"  class="btn-togle"><i class="fas fa-bars toggle-icon"></i></button>
                    </div>
                  </div>
                  <div id="toggleDiv{{ $index }}" class="toggle-content">
                    <div class="toggle-container">
                        <div class="toggle-text">
                          <p class="t-font">
                            <span class="rounded-circle ft-p">
                              <i class="fas fa-chevron-right text-white ft-p-i"></i>
                            </span>
                            {{$data->domain}}</p>
                        </div>
                        <div class="toggle-text">
                          <p class="t-font">
                            <span class="rounded-circle ft-p">
                              <i class="fas fa-chevron-right text-white ft-p-i"></i>
                            </span>
                            {{$data->qualification}}</p>
                        </div>
                        <div class="toggle-text">
                          <p class="t-font">
                            <span class="rounded-circle ft-p">
                              <i class="fas fa-chevron-right text-white ft-p-i"></i>
                            </span>
                            {{$data->experience}}</p>
                        </div>
                    </div>
                  </div>
             </div>
           </div>
          </div>
          
      @endforeach
    </div>
   </div>
   </div>
   <div id="container2" class="data-container job-box">
    <div class="container-fluid">
      <div class="row">
      @foreach ($data1 as $data1)
        <div class="col-md-4 jobs-container">
             <div class="job-offer-div">
                <div class="job-img">
                  <img src="/images/{{$data1->logo}}" width="100%" height="auto" alt="">
               </div>
               <div class="job-text">
                <a href="{{ url('/tenders-description', $data1->id) }}">{{ $data1->title }}</a>
                  <div class="job-info">
                    <p><i class="fas fa-map-marker-alt job-l-color"></i> <span class="job-location">{{$data1->city}}</span>
                      <i class="fas fa-eye job-l-color eye"></i> <span class="job-views">{{ $data1->views }}</span>
                    <i class="fas fa-clock fa-spin fa-xs f-clock-color"></i> <span class="job-date f-clock-color">{{$data1->deadline}}</span></p>
                </div>
                  <div class="container-j">
                      <div class="content">
                        <p><i class="fas fa-building fa-xs f-b-color"></i>{{$data1->company}}</p>
                      </div>
                    </div>
               </div>
             </div>
          </div>
          @endforeach
      </div>
     </div>
   </div>
  </div>
   <div id="container3" class="data-container job-box">
    <div class="container-fluid">
      <div class="row">
      @foreach ($data2 as $data2)
          <div class="col-md-4 jobs-container">
             <div class="job-offer-div">
                <div class="job-img">
                  <img src="/images/{{$data2->logo}}" width="100%" height="auto" alt="">
               </div>
               <div class="job-text">
                <a href="{{ url('/reviews-description', $data2->id) }}">{{ $data2->title }}</a>
                  <div class="job-info">
                    <p class="">
                      <i class="fas fa-eye job-l-color eye ml"></i> <span class="job-views">{{ $data2->views }}</span>
                    <i class="fas fa-clock fa-spin fa-xs f-clock-color"></i> <span class="job-date f-clock-color">{{$data2->deadline}}</span></p>
                  </div>
                  <div class="container-j">
                      <div class="content">
                        <p><i class="fas fa-building fa-xs f-b-color"></i>{{$data2->company}}</p>
                      </div>
                  </div>
               </div>
             </div>
          </div>
          @endforeach
      </div>
     </div>
   </div>
  </div>
  <div class="home-data-bg pt-3">
   <div class="container-fluid">
    <div class="row">
        <div class="col-md-4 mb-3">
            <div class="form-links">
                <a href="/cv">{{__('welcome.CV templates to download')}}</a>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="form-links">
                <a href="/letter">{{__('welcome.Cover letter templates to download')}}</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-links">
                <a href="/interview-article">{{__('welcome.Succeed in your interview')}}</a>
            </div>
        </div>
    </div>
  </div>
  <div class="container-fluid">
    <div class="row">
      @foreach ($data3 as $data3)
      <div class="col-md-4">
         <div class="cvs-container">
          <div class="cvs-img">
            <img src="/images/{{$data3->image}}" width="100%" height="100%" alt="">
          </div>
          <div class="cvs-text">
            <h6>{{__('welcome.Study level')}}: <span class="cv-t-s">XXXXXXX</span></h6>
            <h6>
            {{__('welcome.Field of Study')}}: <span class="cv-t-s">XXXXXXX </span>
            </h6>
            <h6>
            {{__('welcome.AGE')}}: <span class="cv-t-s"> XXXXXXX</span>
            </h6>
            <h6>
            {{__('welcome.NAME')}}: <span class="cv-t-s">XXXXXXX
              </span></h6>
            <h6>
            {{__('welcome.Contact')}}:<span class="cv-t-s">XXXXXXX</span>
            </h6>
          </div>
         </div>
      </div>
      @endforeach
    </div>
  </div>
</div>
<div>

  <div id="imageCarousel" class="carousel slide mt-5 mb-5" data-bs-ride="carousel">       
    <!-- Slides -->
    <div class="carousel-inner container">
      @foreach ($ade as $ade)
        <!-- Slide 1 -->
        <div class="carousel-item active">
            <div class="row">
              <div class="col-md-2"></div>
                <div class="col-md-8">
                  <center>  <img src="/images/{{$ade->image}}" class="d-block w-100" alt="Image 1"></center>
                </div>      
              <div class="col-md-2"></div>

            </div>
        </div>
        @endforeach
        <!-- Slide 2 -->
    </div>
</div>
   @include('footerslider');
   @include('footer');

   <script>
    function toggleContent(index) {
      var toggleDiv = document.getElementById('toggleDiv' + index);
      toggleDiv.classList.toggle('show');
    }
  </script>
  
  
  <script>
    function showContainer(containerNumber) {
      // Hide all containers
      var containers = document.getElementsByClassName('data-container');
      for (var i = 0; i < containers.length; i++) {
        containers[i].style.display = 'none';
      }

      // Show the selected container
      var container = document.getElementById('container' + containerNumber);
      container.style.display = 'block';
    }
  </script>

