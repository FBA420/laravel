@include('header');
@if (Session::has('success'))
    <div class="alert alert-success text-center">
        {{ Session::get('success') }}
    </div>
@endif
<div class="container py-4" style="background: #fff">
    <div class="row" id="divContact">
      <div class="col-md-8 textAlign">
        <h5>Envoyez-nous un message</h5>
        <form action="{{ url('contact') }}" method="post">
          @csrf
          <div class="form-row">
            <div class="col-md-6 form-group">
              <label for="nom">Nom <span class="required_field" data-toggle="tooltip" data-placement="right" title="champ obligatoire">*</span></label>
              <input required id="nom" name="name" required class="form-control">
            </div>
            <div class="col-md-6 form-group">
              <label for="email">Email <span class="required_field" data-toggle="tooltip" data-placement="right" title="champ obligatoire">*</span></label>
              <input required id="email" type="email" name="email" required class="form-control">
            </div>
            <div class="col-md-12 form-group">
              <label for="sujet">Sujet <span class="required_field" data-toggle="tooltip" data-placement="right" title="champ obligatoire">*</span></label>
              <input required id="sujet" type="text" name="subject" required class="form-control">
            </div>
            <div class="col-md-12 form-group">
              <label for="description">Message <span class="required_field" data-toggle="tooltip" data-placement="right" title="champ obligatoire">*</span></label>
              <textarea id="description" name="message" required class="editor form-control"></textarea>
            </div>
            <div class="form-group col-md-6">
              <div class="captcha mb-3">
                <br>
                <img src="" alt="">
                <button type="button" class="btn btn-danger ml-2" id="refresh-captcha">↻</button>
              </div>
              <input  id="captcha" type="text" name="captcha"  class="form-control" placeholder="Saisir le captcha">
            </div>
          </div>
          <br>
          
          <input  type="submit" class="btn btn-success" value="Submit">
        </form>
        <br>
        <a class="btn btn-info float-right text-light" href="/login">Nouveau client</a><br>
      </div>
      <div class="col-md-4 border textAlign mt-sm-3 pt-2">
        @foreach ($data as $data)
        <h6>{{$data->heading}}</h6>
       <i class="fas fa-map-marker-alt"></i>{{$data->address}}<br>
         &nbsp;&nbsp; {{$data->name}}<br>
        <i class="fa fa-phone-square" aria-hidden="true"></i>{{$data->contact}}<br>
        <i class="far fa-envelope"></i> {{$data->mail}}<br><br>
        @endforeach
      </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <div class="google-map">
                <iframe width="100%" height="300" id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30340.963190868682!2d-16.02409782429913!3d18.089119610334436!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xe964dbe747180ef%3A0x644277e325c4fb55!2sCOMPUTERS%20CENTER!5e0!3m2!1sen!2s!4v1598954718106!5m2!1sen!2s" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
              </div>
            </div>
        </div>
      </div>
@include('footer')
