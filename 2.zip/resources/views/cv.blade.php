@include('header');
     <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="c-l-heading">
                    <h5>{{__('welcome.CV templates to download')}}</h5>
                </div>
            </div>
        </div>
     </div>
     <div class="container">
        <div class="row">
   @foreach ($data3 as $data3)
     <div class="col-md-3">
      <p  class="cv-name">{{$data3->name}}</p>
      <center><a href="/pdffiles/{{$data3->cvfile}}" download>
        <img src="/pdffiles/{{$data3->cvimage}}" width="250px" class="cv-img" height="300px"><br><br>
         </a></center>
     </div>    
    @endforeach
    </div>
     </div>
     @include('footer')
</body>
</html>