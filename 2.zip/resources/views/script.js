// formInscrivez.blade.php script starts
    $index = 1;
    $(document).ready(function() {
        var i = 1;
        $('#add').click(function() {
            i++;
            $('#dynamic_field').append('<tr id="row' + i +
                '"><td><input type="file" name="piecejointe[]"  class="form-control name_list" /></td><td><button type="button" name="remove" id="' +
                i + '" class="btn btn-danger btn_remove">X</button></td></tr>');
        });

        $(document).on('click', '.btn_remove', function() {
            var button_id = $(this).attr("id");
            $('#row' + button_id + '').remove();
        });

    });

    $(document).on("click", "#formationBten", function() {
        $index++;
        $('#formation').append('<div class="row" id="form" >' +
            '<div class="col-sm-12"><button type="button" name="remove" class="btn btn-danger formremove" style="float: right;">X</button></div>' +
            '<div class="col-sm-4"><span style="font-weight: 900; "><input type="hidden" class="form-control" name="id_foramtion[]" value="' +
            $index +
            '">  Date Debut</span> <input name="date_debut[]" required type="date" class="form-control">' +
            '</div> <div class="col-sm-4"><span style="font-weight: 900; "> Date Fin </span><input name="date_fin[]" type="date" class="form-control"> </div>' +
            '<div class="col-sm-4"> <span style="font-weight: 900;">Formation en cours</span> <input name="encour_f[]" value="' +
            $index + '" type="checkbox" class="form-control"></div>' +
            '<div class="col-sm-3" style="margin-top: 15px;"><span style="font-weight: 900; "> Titre de formation </span>' +
            '<select name="titre_formation[]" type="text" class="form-control" required>' +
            '<option value="Certificat">Certificat</option><option value="Brevet">Berevet</option>' +
            '<option value="Bac">Bac</option><option value="Bac+2">Bac+2</option>' +
            '<option value="Licence">Licence</option><option value="Bac+4">Bac+4</option>' +
            '<option value="Master">Master</option><option value="Doctorat">Doctorat</option>' +
            '<option value="Autres">Autres</option></select></div>' +
            '<div class="col-sm-3" style="margin-top: 15px;"><span style="font-weight: 900;">Spécialité</span><input name="specialite[]" type="text" class="form-control"></div>' +
            '<div class="col-sm-3" style="margin-top: 15px;"><span style="font-weight: 900; "> Etablissement </span> <input name="etablissement[]" type="text" required class="form-control"></div>' +
            '<div class="col-sm-3" style="margin-top: 15px;"><span style="font-weight: 900;">Ville </span><input name="ville[]" type="text" class="form-control" required></div>' +
            '<div class="col-sm-12" style="margin-top: 15px;"> <textarea class="form-control" name="description_formation[]" id="form6Example7" rows="4" cols="54" placeholder="Saisire une descrition detaillee de votre formation"></textarea><br></div></div><br>'
        )

    });

    $(document).on("click", "#experBtn", function() {
        $index++;
        $('#experiance').append('<div class="row" id="exper" >' +
            '<div class="col-sm-12 text-right"><button type="button" name="remove" id="expremove" class="btn btn-danger">X</button></div>' +

            '<div class="col-sm-4"> <span style="font-weight: 900; ;"> Date Debut </span> <input type="hidden" class="form-control" name="id_experience[]" value="' +
            $index + '"> <input name="date_debit[]" type="date" class="form-control" > </div>' +
            '<div class="col-sm-4"> <span style="font-weight: 900; "> Date Fin </span> <input name="date_fin_Exp[]" type="date" class="form-control"></div>' +
            '<div class="col-sm-4"> <span style="font-weight: 900; ">Experience en cours</span> <input name="encour_e[]" value="' +
            $index + '" type="checkbox" class="form-control"></div>' +

            '<div class="col-sm-6" style="margin-top: 15px;"> <span style="font-weight: 900;"> Titre d\'experience </span> <input name="titre_projet[]" type="text"  class="form-control"> </div>' +
            '<div class="col-sm-6" style="margin-top: 15px;"> <span style="font-weight: 900;"> Nom d\'etablissement </span> <input name="nom_entreprise[]"  type="text" class="form-control"></div>' +

            '<div class="col-sm-12" style="margin-top: 15px;"><textarea class="form-control" name="description_experience[]" id="form6Example7" rows="4" cols="54" placeholder="Saisire une descrition detaillee de votre experience"></textarea><br></div>' +
            '</div><br>')
    });

    $(document).on("click", "#addLangue", function() {
        $index++;
        $('#langue').append('<div class="row" id="form">' +
            '<div class="col-sm-12 text-right"><br><button type="button" name="remove"  class="btn btn-danger formremove" ">X</button></div>' +
            '<div class="col-md-6"><span style="font-weight: 900;">Langue</span>' +
            '<select required="true" name="nom_langue[]" class="form-control"><option value=""></option>' +
            '<option value="Arabe">Arabe </option><option value="Français">Français </option>' +
            '<option value="Anglais">Anglais </option>' +
            '<option value="Espagnol">Espagnol </option><option value="Chinois">Chinois </option>' +
            '<option value="Russe">Russe </option><option value="Allemand">Allemand </option>' +
            '</select></div><div class="col-md-6"><span style="font-weight: 900;">Niveau</span><select required="true" name="niveau_langue[]" class="form-control">' +
            '<option value=""> </option> <option value="Excellent">Excellent </option> <option value="Bien">Bien </option>' +
            '<option value="Moyen">Moyen </option><option value="Débutant">Débutant </option>' +
            '</select></div> </div>'
        )
    });

    $(document).on("click", "#addSkills", function() {
        $index++;
        $('#skills').append('<div class="row" id="form">' +
            '<div class="col-sm-12 text-right"><br><button type="button" name="remove"  class="btn btn-danger formremove" ">X</button></div>' +
            '<div class="col-md-6"> <span style="font-weight: 900;">Compétences</span>' +
            '<input type="text" name="skills_nom[]" class="form-control"> </div> <div class="col-md-6"> <span style="font-weight: 900;">Niveau</span>' +
            '<select required="true" name="niveau_skills[]" class="form-control"> <option value=""> </option> <option value="90">Excellent</option>' +
            '<option value="75">Bien</option> <option value="50">Moyen</option> <option value="15">Débutant</option>' +
            '</select> </div> </div>'
        )
    });

    $(document).on('click', '#expremove', function() {
        $(this).closest("#exper").remove();
    });

    $(document).on('click', '.formremove', function() {
        $(this).closest("#form").remove();
    });

    $(document).on('click', '#retireImg', function() {
        $("#img").html('<img src="https://rimtic.com/cvtheque/images/profile.png">' +
            '<input type="file" name="image" class="form-control" />');

    });
    $(document).on('click', '#retireCV', function() {
        $("#cv").html('<table class="" id="dynamic_field" style="width: 100%;">' +
            '<tr> <td style="width: 100%;">' +
            '<input required="true" type="file" name="piecejointe[]" class="form-control name_list" />' +
            '</td> </tr> </table>');
    });
// formInscrivez.blade.php script ends

// signup.blade.php starts
        $(document).ready(function() {
            /*$('body').bind('copy', function (e) {
        e.preventDefault();
    });
   
    $("body").on("contextmenu",function(e){
        return false;
    });*/

            $('#appOff').click(function(e) {
                $(this).css("backgroundColor", "#ad081f");
                $('.p11').css("backgroundColor", "#f1efef");
                $('.p132').css("backgroundColor", "#f1efef");
                $('.emploi').css("color", "black");
                $('.appels').css("color", "white");
                $('.publi').css("color", "black");
                $('#tab-content').css("border-color", "#ad081f");
            });
            $('#offEmp').click(function(e) {
                $(this).css("backgroundColor", "#255025");
                $('.p12').css("backgroundColor", "#f1efef");
                $('.p132').css("backgroundColor", "#f1efef");
                $('.appels').css("color", "black");
                $('.emploi').css("color", "white");
                $('.publi').css("color", "black");
                $('#tab-content').css("border-color", "#255025");
            });
            $('#publi').click(function(e) {
                $(this).css("backgroundColor", "#594c06");
                $('.p12').css("backgroundColor", "#f1efef");
                $('.p11').css("backgroundColor", "#f1efef");
                $('.appels').css("color", "black");
                $('.emploi').css("color", "black");
                $('.publi').css("color", "white");
                $('#tab-content').css("border-color", "#594c06");
            });

        });
  // signup.blade.php ends