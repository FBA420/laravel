@include('header')
@if (Session::has('success'))
    <div class="alert alert-success text-center">
        {{ Session::get('success') }}
    </div>
@endif
<div style="margin-top: 20px;">
<div >
<div class="container">
    <div class="row bg-light">
        <div class="col-sm-12">
            <center>
                <h3 style="font-weight: 900; padding: 10px; ">{{__('welcome.Submit your resume')}}</h3>
            </center>
        </div>
    </div>
<br>
<div class="bg-light p-4">
<form action="{{ url('cvform') }}" method="post" enctype="multipart/form-data">
  @csrf
  <div class="container">
    <div class="row">
      <div class="col-sm-6">
        <label for="name">{{__('welcome.NAME')}}</label>
        <input required type="text" class="form-control" name="name" id="name">
      </div>
      <div class="col-sm-6">
        <label for="contact">{{__('welcome.Contact')}}</label>
        <input required type="number" class="form-control" name="contact" id="contact">
      </div>
    </div>
    <div class="row">
      <div class="col-sm-6">
        <label for="age">{{__('welcome.AGE')}}</label>
        <input required type="number" class="form-control" name="age" id="age" required>
      </div>
      <div class="col-sm-6">
        <label for="qualification">{{__('welcome.Qualification')}}</label>
        <input required type="text" class="form-control" name="qualification" id="qualification" required>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12">
        <label for="field">{{__('welcome.Field of Study')}}</label>
        <input required type="text" class="form-control" name="field" required>
      </div>
      <div class="col-sm-12">
        <label class="fontAlmari form-label">{{__('welcome.Candidate Image')}}</label>
        <input required type="file" name="image" class="form-control">
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12">
        <label class="fontAlmari form-label">{{__('welcome.Upload CV in PDF')}}</label>
        <input required type="file" name="cvfile" class="form-control">
      </div>
      <div class="col-sm-12">
        <label class="fontAlmari form-label">{{__('welcome.Upload CV in JPG')}}</label>
        <input required type="file" name="cvpic" class="form-control">
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12">
        <label class="fontAlmari form-label">{{__('welcome.Upload Letter in PDF')}}</label>
        <input required type="file" name="letter" class="form-control">
      </div>
    </div>
    <div class="row" style="margin-top: 30px;">
      <div class="col-sm-12 text-center">
        <button type="submit" class="btn btn-success btn-lg" >{{__('welcome.Submit')}}</button>
      </div>
    </div>
  </div>
</form>
</div>
@include('footer')
 





