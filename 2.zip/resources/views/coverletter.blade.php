@include('header');
     <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="c-l-heading">
                    <h5> {{__('welcome.Cover letter templates to download')}}</h5>
                </div>
            </div>
        </div>
     </div>
     <div class="container">
        <div class="row">
            <div class="col-md-12">
               <div class="c-l-container">
               @foreach ($data3 as $data3)
                    <div class="c-l-box">
                         <a class="letter-link" href="/pdffiles/{{$data3->letter}}" download><i class="fas fa-download dl"></i>Letter Of Motivation</a>
                    </div>
                  @endforeach
               </div>
            </div>
        </div>
     </div>
     @include('footer')
