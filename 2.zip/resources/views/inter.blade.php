@include('header')
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="c-l-heading">
                <h5>
                    {{__('welcome.Succeed in your interview')}}
                </h5>
            </div>
            @foreach ($data as $data)
            <div class="interview-parent" onclick="toggleDiv(this)">
            <h6><i class="fas fa-check-circle"></i>
                {{$data->heading}}  <i class="fas fa-caret-down"></i></h6>
            </div>
            <div class="interview-child">
                <h5>{{$data->heading}}</h5>
                <div class="row mt-3">
                    <div class="col-md-8"><h6>{{$data->subheading1}}</h6>
                    <p>{{$data->paragraph1}}</p>
                    </div>
                    <div class="col-md-4">
                        <img src="/images/{{$data->image1}}" width="100%" height="100%" alt="pic">
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-8"><h6>{{$data->subheading2}}</h6>
                    <p>{{$data->paragraph2}}</p>
                    </div>
                    <div class="col-md-4">
                        <img src="/images/{{$data->image2}}" width="100%" height="100%" alt="pic">
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-8"><h6>{{$data->subheading3}}</h6>
                    <p>{{$data->paragraph3}}</p>
                    </div>
                    <div class="col-md-4">
                        <img src="/images/{{$data->image3}}" width="100%" height="100%" alt="pic">
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-8"><h6>{{$data->subheading4}}</h6>
                    <p>{{$data->paragraph4}}</p>
                    </div>
                    <div class="col-md-4">
                        <img src="/images/{{$data->image4}}" width="100%" height="100%" alt="pic">
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-8"><h6>{{$data->subheading5}}</h6>
                    <p>{{$data->paragraph5}}</p>
                    </div>
                    <div class="col-md-4">
                        <img src="/images/{{$data->image5}}" width="100%" height="100%" alt="pic">
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
 </div>
@include('footer')
 <script>
    function toggleDiv(element) {
      var childDiv = element.nextElementSibling;
      childDiv.style.display = childDiv.style.display === 'none' ? 'block' : 'none';
    }
  </script>