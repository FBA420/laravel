@include('header')
<div class="container">

<div style="padding: 20px;">
  <div class="row">
    <div class="col-lg-12 col-12">
        <p class="fontAlmari" style="font-size: 13px; display: flex; justify-content: flex-end; align-items: center;">
          <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="clock" class="svg-inline--fa fa-clock fa-xs d-fa-i text-danger" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" color="#255025" style="width: 16px;">
            <path fill="currentColor" d="M256 512C114.6 512 0 397.4 0 256S114.6 0 256 0S512 114.6 512 256s-114.6 256-256 256zM232 120V256c0 8 4 15.5 10.7 20l96 64c11 7.4 25.9 4.4 33.3-6.7s4.4-25.9-6.7-33.3L280 243.2V120c0-13.3-10.7-24-24-24s-24 10.7-24 24z"></path>
          </svg>
          <span style="color: rgb(173, 8, 31); margin-right: 5px;">{{$data2->deadline}}</span>
        </p>
        <p class="fontAlmari" style="font-size: 13px; display: flex; justify-content: flex-end; align-items: center;">
          <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="eye" class="svg-inline--fa fa-eye fa-xs d-fa-i text-success" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" color="#255025" style="width: 16px;">
            <path fill="currentColor" d="M288 32c-80.8 0-145.5 36.8-192.6 80.6C48.6 156 17.3 208 2.5 243.7c-3.3 7.9-3.3 16.7 0 24.6C17.3 304 48.6 356 95.4 399.4C142.5 443.2 207.2 480 288 480s145.5-36.8 192.6-80.6c46.8-43.5 78.1-95.4 93-131.1c3.3-7.9 3.3-16.7 0-24.6c-14.9-35.7-46.2-87.7-93-131.1C433.5 68.8 368.8 32 288 32zM432 256c0 79.5-64.5 144-144 144s-144-64.5-144-144s64.5-144 144-144s144 64.5 144 144zM288 192c0 35.3-28.7 64-64 64c-11.5 0-22.3-3-31.6-8.4c-.2 2.8-.4 5.5-.4 8.4c0 53 43 96 96 96s96-43 96-96s-43-96-96-96c-2.8 0-5.6 .1-8.4 .4c5.3 9.3 8.4 20.1 8.4 31.6z"></path>
          </svg>
          <span style="color: green; margin-right: 5px;">{{$data2->views}}</span>
        </p>
      </div>
    <div class="col-lg-12 col-12">
      <center>
        <img class="image" src="/images/{{$data2->logo}}" alt="Profile" style="max-width: 200px;">
        <p class="fontAlmari" style="text-align: center; font-weight: bold; margin-top: 1px;">{{$data2->company}}</p>
      </center>
    </div>
    <div class="col-lg-12 col-12">
      <p class="fontAlmari" style="text-align: center; font-size: 20px; margin: 10px;">{{$data2->heading}}</p>
    </div>

</div>

    <div class="col-lg-12 col-12">
      <div class="" style="padding: 30px;">
        {!! $data2->description !!}</div>
<div class="col-lg-12 col-12 ">
  <div class="row" style="margin: 3px 10px 5px; border-bottom: 1px solid rgb(210, 207, 207); padding: 10px 10px 5px;">
    <div class="psj col-lg-2 col-2" style="margin: auto;">
      <img src="#" alt="" style="width: 32px; height: auto;">
    </div>
    <div class="psj col-lg-10 col-10">
      <a href="#" target="_blank" download style="margin: 5px 7px 0px; font-weight: 400; color: rgb(34, 123, 28);">
        {{$data2->file}}
      </a>
    </div>
  </div>
</div>
<div class="col-lg-12 col-12">
  <div class="div-partager" style="border: 1px solid black; border-radius: 5px;">
    <div class="row" style="padding: 4px;">
      <div class="col-lg-6 col-5">
        <span class="fontAlmari" style="font-weight: bold;">Partager :</span>
        <button aria-label="facebook" class="react-share__ShareButton" style="background-color: transparent; border: none; padding: 0px; font: inherit; color: inherit; cursor: pointer;">
          <svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="facebook" class="svg-inline--fa fa-facebook " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" style="padding: 0px 3px; color: rgb(73, 139, 196); font-size: 20px;">
            <path fill="currentColor" d="M504 256C504 119 393 8 256 8S8 119 8 256c0 123.78 90.69 226.38 209.25 245V327.69h-63V256h63v-54.64c0-62.15 37-96.48 93.67-96.48 27.14 0 55.52 4.84 55.52 4.84v61h-31.28c-30.8 0-40.41 19.12-40.41 38.73V256h68.78l-11 71.69h-57.78V501C413.31 482.38 504 379.78 504 256z"></path>
          </svg>
        </button>
        <button aria-label="whatsapp" class="react-share__ShareButton" style="background-color: transparent; border: none; padding: 0px; font: inherit; color: inherit; cursor: pointer;">
          <svg aria-hidden="true" focusable="false" data-prefix="fab" data-icon="whatsapp" class="svg-inline--fa fa-whatsapp " role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" style="padding: 0px 3px; color: rgb(37, 211, 102); font-size: 20px;">
            <path fill="currentColor" d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path>
          </svg>
        </button>
      </div>
    </div>
  </div>
</div>
<div class="col-lg-12 col-12"></div>
</div>
</div>
    </div>
@include('footer')