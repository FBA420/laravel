
<x-app-layout>

</x-app-layout>



<!DOCTYPE html>
<html lang="en">

@include('admin.adminheader')
<body>
<div class="bg-dark text-center p-4 admin-h"><h1 class="admin-h">ADMIN DASHBOARD</h1></div>
<div class="main-div">
<div class="sidebar">
@include('admin.admindb')
</div>
<!-- Page content -->
<div class="content">
<h1 class="text-light text-center">Cv Data</h1>
<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover bg-light text-dark">
      <thead>
        <tr>
          <th>Id</th>
          <th>Name</th>
          <th>Contact</th>
          <th>Age</th>
          <th>Qulaification</th>
          <th>Field Of Study</th>
          <th>Image</th>
          <th>CV</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        @foreach ($data as $data)
        <tr>
          <td class="text-dark">{{$data->id}}</td>
          <td class="text-dark">{{$data->name}}</td>
          <td class="text-dark">{{$data->contact}}</td>
          <td class="text-dark">{{$data->age}}</td>
          <td class="text-dark">{{$data->qualification}}</td>
          <td class="text-dark">{{$data->field}}</td>
          <td class="text-dark"><img src="/images/{{$data->image}}" width="150px" height="100px" alt="pic"></td>
          <td class="text-dark"><img src="/pdffiles/{{$data->cvimage}}" width="150px" height="100px" alt="cv"></td>
          <td><a class="del-btn" href="{{url('/deletecvdata',$data->id)}}">Delete</a></td>
      </tr>
      @endforeach
      </tbody>
    </table>
  </div>
  
</div>
</div>
</body>
</html>

@include('admin.adminfooter')