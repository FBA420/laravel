<x-app-layout>

</x-app-layout>

<!DOCTYPE html>
<html lang="en">

@include('admin.adminheader')
<body>
  <div class="bg-dark text-center p-4 admin-h"><h1 class="admin-h">ADMIN DASHBOARD</h1></div>
   <div class="main-div">
  <div class="sidebar">
    @include('admin.admindb')
  </div>
   <!-- Page content -->
<div class="content">

</div>
</div>
</body>
</html>

@include('admin.adminfooter')