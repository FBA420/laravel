<x-app-layout>

</x-app-layout>

<!DOCTYPE html>
<html lang="en">

@include('admin.adminheader')
<body>
  <div class="bg-dark text-center p-4 admin-h"><h1 class="admin-h">ADMIN DASHBOARD</h1></div>
   <div class="main-div">
  <div class="sidebar">
    @include('admin.admindb')
  </div>
   <!-- Page content -->
<div class="content">
    <div class="col md-8 text-light bg-dark p-4">
        <h3 class="text-center">Update Interview Article</h3>
         <form action="{{url('/editinterview',$data->id)}}" method="post" enctype="multipart/form-data">
             @csrf
             <div class="mb-3">
              <label for="" class="form-label">Main Heading:</label>
              <input type="text" name="heading" id="" class="form-control" value="{{$data->heading}}"  >
            </div>
            <div class="mb-3">
             <label for="" class="form-label">Sub Heading1:</label>
             <input type="text" name="head1" id="" class="form-control" value="{{$data->subheading1}}"  >
            </div>
            <div class="mb-3">
             <label for="" class="form-label">Paragraph1:</label>
             <textarea name="para1" class="form-control"  id="" cols="30" rows="10">{{$data->paragraph1}}</textarea>
            </div> 
            <div class="mb-3">
              <label for="" class="form-label">image1:</label>
              <input type="file" name="img1" id="" class="form-control" >
             </div> 
             <div class="mb-3">
              <label for="" class="form-label">Sub Heading2:</label>
              <input type="text" name="head2" id="" class="form-control" value="{{$data->subheading2}}"  >
             </div>
             <div class="mb-3">
              <label for="" class="form-label">Paragraph2:</label>
              <textarea name="para2" class="form-control"  id="" cols="30" rows="10">{{$data->paragraph2}}</textarea>
             </div> 
             <div class="mb-3">
               <label for="" class="form-label">image2:</label>
               <input type="file" name="img2" id="" class="form-control">
              </div> 
              <div class="mb-3">
                <label for="" class="form-label">Sub Heading3:</label>
                <input type="text" name="head3" id="" class="form-control"  value="{{$data->subheading3}}">
               </div>
               <div class="mb-3">
                <label for="" class="form-label">Paragraph3:</label>
                <textarea name="para3" class="form-control"  id="" cols="30" rows="10">{{$data->paragraph3}}</textarea>
               </div> 
               <div class="mb-3">
                 <label for="" class="form-label">image3:</label>
                 <input type="file" name="img3" id="" class="form-control" >
                </div> 
                <div class="mb-3">
                  <label for="" class="form-label">Sub Heading4:</label>
                  <input type="text" name="head4" id="" class="form-control" value="{{$data->subheading4}}" >
                 </div>
                 <div class="mb-3">
                  <label for="" class="form-label">Paragraph4:</label>
                  <textarea name="para4" class="form-control"  id="" cols="30" rows="10">{{$data->paragraph4}}</textarea>
                 </div> 
                 <div class="mb-3">
                   <label for="" class="form-label">image4:</label>
                   <input type="file" name="img4" id="" class="form-control" >
                  </div> 
                  <div class="mb-3">
                    <label for="" class="form-label">Sub Heading5:</label>
                    <input type="text" name="head5" id="" class="form-control" value="{{$data->subheading5}}" >
                   </div>
                   <div class="mb-3">
                    <label for="" class="form-label">Paragraph5:</label>
                    <textarea name="para5" class="form-control"  id="" cols="30" rows="10">{{$data->paragraph5}}</textarea>
                   </div> 
                   <div class="mb-3">
                     <label for="" class="form-label">image5:</label>
                     <input type="file" name="img5" id="" class="form-control" >
                    </div> 
            <center> <button type="submit" value="submit" class="btn btn-lg btn-light">Update</button> </center>
         </form>
        </div>
</div>
</div>
</body>
</html>

@include('admin.adminfooter')