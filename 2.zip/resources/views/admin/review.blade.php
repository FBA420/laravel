
<x-app-layout>

</x-app-layout>



<!DOCTYPE html>
<html lang="en">

@include('admin.adminheader')
<body>
<div class="bg-dark text-center p-4 admin-h"><h1 class="admin-h">ADMIN DASHBOARD</h1></div>
<div class="main-div">
<div class="sidebar">
@include('admin.admindb')
</div>
<!-- Page content -->
<div class="content">
<h1 class="text-light text-center">Leave a review</h1>
<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover bg-light text-dark">
      <thead>
        <tr>
          <th>Id</th>
          <th>Company</th>
          <th>Deadline</th>
          <th>Title</th>
          <th>Logo</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        @foreach ($data as $data)
        <tr>
          <td class="text-dark">{{$data->id}}</td>
          <td class="text-dark">{{$data->company}}</td>
          <td class="text-dark">{{$data->city}}</td>
          <td class="text-dark">{{$data->deadline}}</td>
          <td class="text-dark">{{$data->title}}</td>
          <td class="text-dark"><img src="/images/{{$data->logo}}" width="150px" height="100px" alt="pic"></td>
          <td><a class="del-btn" href="{{url('/deletereview',$data->id)}}">Delete</a></td>
      </tr>
      @endforeach
      </tbody>
    </table>
  </div>
  
</div>
</div>
</body>
</html>

@include('admin.adminfooter')