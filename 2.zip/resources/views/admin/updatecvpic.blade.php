<x-app-layout>

</x-app-layout>

<!DOCTYPE html>
<html lang="en">

@include('admin.adminheader')
<body>
  <div class="bg-dark text-center p-4 admin-h"><h1 class="admin-h">ADMIN DASHBOARD</h1></div>
   <div class="main-div">
  <div class="sidebar">
    @include('admin.admindb')
  </div>
   <!-- Page content -->
<div class="content">
  <div class="col md-8 text-light bg-dark p-4">
    <h3 class="text-center">UpdatenCV Images </h3>
     <form action="{{url('/updatecvpic',$data->id)}}" method="post" enctype="multipart/form-data">
         @csrf
        <div class="mb-3">
         <label for="" class="form-label">Upload Image</label>
         <input type="file" name="image" id="" class="form-control" >
        </div> 
        <center> <button type="submit" value="submit" class="btn btn-lg btn-light">Update</button> </center>
     </form>
    </div>
</div>
</div>
</body>
</html>

@include('admin.adminfooter')