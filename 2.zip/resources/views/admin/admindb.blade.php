
  <a href="/adminhome">Dashboard</a>
  <a href="{{url('/users')}}">Users</a>
  <a href="{{url('/cvpic')}}">ADD CV Image</a>
  <a href="{{url('/cvdata')}}">CVs Data</a>
  <a href="{{url('/joboffer')}}">Job Offers</a>
  <a href="{{url('/tenders')}}">Tenders</a>
  <a href="{{url('/review')}}">Review</a>
  <a href="{{url('/contact')}}">Contact</a>
  <a href="{{url('/interview')}}">Interview</a>
  <button class="dropdown-btn">Website
    <i class="fas fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="{{url('/information')}}">Edit Contact Information</a>
    <a href="{{url('/header')}}">Edit Header</a>
    <a href="{{url('/footer')}}">Edit Footer</a>
    <a href="{{url('/advertisement')}}">Add Advertisment</a>
  </div>
 