
<x-app-layout>

</x-app-layout>



<!DOCTYPE html>
<html lang="en">

@include('admin.adminheader')
<body>
<div class="bg-dark text-center p-4 admin-h"><h1 class="admin-h">ADMIN DASHBOARD</h1></div>
<div class="main-div">
<div class="sidebar">
@include('admin.admindb')
</div>
<!-- Page content -->
<div class="content">
<h1 class="text-light text-center">Contact Data</h1>
<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover bg-light text-dark">
      <thead>
        <tr>
          <th>Id</th>
          <th>Name</th>
          <th>Email</th>
          <th>Subject</th>
          <th>Message</th>
          <th>Captcha</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        @foreach ($data as $data)
        <tr>
          <td class="text-dark">{{$data->id}}</td>
          <td class="text-dark">{{$data->name}}</td>
          <td class="text-dark">{{$data->email}}</td>
          <td class="text-dark">{{$data->subject}}</td>
          <td class="text-dark">{{$data->message}}</td>
          <td class="text-dark">{{$data->captcha}}</td>
          <td><a class="del-btn" href="{{url('/deletecontact',$data->id)}}">Delete</a></td>
      </tr>
      @endforeach
      </tbody>
    </table>
  </div>
  
</div>
</div>
</body>
</html>

@include('admin.adminfooter')