<x-app-layout>

</x-app-layout>

<!DOCTYPE html>
<html lang="en">

@include('admin.adminheader')
<body>
  <div class="bg-dark text-center p-4 admin-h"><h1 class="admin-h">ADMIN DASHBOARD</h1></div>
   <div class="main-div">
  <div class="sidebar">
    @include('admin.admindb')
  </div>
   <!-- Page content -->
<div class="content">
  <div class="col md-8 text-light bg-dark p-4">
    <h3 class="text-center">Enter Contact Information</h3>
     <form action="{{url('/uploadinformation')}}" method="post" enctype="multipart/form-data">
         @csrf
         <div class="mb-3">
          <label for="" class="form-label">Address:</label>
          <input type="text" name="address" id="" class="form-control"  >
        </div>
        <div class="mb-3">
          <label for="" class="form-label">Heading</label>
          <input type="text" name="heading" id="" class="form-control"  >
         </div>
        <div class="mb-3">
         <label for="" class="form-label">Contact Number:</label>
         <input type="telephone" name="phone" id="" class="form-control"  >
        </div>
        <div class="mb-3">
         <label for="" class="form-label">Mail</label>
         <input type="email" name="email" id="" class="form-control" >
        </div> 
        <div class="mb-3">
            <label for="" class="form-label">Name</label>
            <input type="text" name="name" id="" class="form-control" >
           </div> 
        <center> <button type="submit" value="submit" class="btn btn-lg btn-light">Submit</button> </center>
     </form>
    </div>
    <h1 class="text-light text-center">Contact Information</h1>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover bg-light text-dark">
          <thead>
            <tr>
              <th>Id</th>
              <th>Address</th>
              <th>Mail</th>
              <th>Contact</th>
              <th>Name</th>
              <th>Heading</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            @foreach ($data as $data)
            <tr>
              <td class="text-dark">{{$data->id}}</td>
              <td class="text-dark">{{$data->address}}</td>
              <td class="text-dark">{{$data->mail}}</td>
              <td class="text-dark">{{$data->contact}}</td>
              <td class="text-dark">{{$data->name}}</td>
              <td class="text-dark">{{$data->heading}}</td>
              <td><a class="del-btn mb-5" href="{{url('/deleteinformation',$data->id)}}">Delete</a><br><br>
                  <a class="del-btn mt-5" href="{{url('/updateinformation',$data->id)}}">Edit</a></td>
          </tr>
          @endforeach
          </tbody>
        </table>
      </div>
      
</div>
</div>
</body>
</html>

@include('admin.adminfooter')