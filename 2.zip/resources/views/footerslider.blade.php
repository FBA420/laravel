<div id="imageCarousel" class="carousel slide" data-bs-ride="carousel">       
    <!-- Slides -->
    <div class="carousel-inner container">
        <!-- Slide 1 -->
        <div class="carousel-item active">
            <div class="row">
                @foreach ($foot2 as $foot2)
                <div class="col-md-2 col-6">
                    <img src="/images/{{$foot2->image}}" class="d-block w-100" alt="Image 1">
                </div>
                @endforeach
            </div>
        </div>
        <!-- Slide 2 -->
        <div class="carousel-item">
            <div class="row">
                @foreach ($foot3 as $foot3)
                <div class="col-md-2 col-6">
                    <img src="/images/{{$foot3->image}}" class="d-block w-100" alt="Image 7">
                </div>
                @endforeach
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script>
    const carousel = new bootstrap.Carousel(document.querySelector('#imageCarousel'), {
        interval: 1000 // Slide interval in milliseconds (10 seconds)
    });
</script>

