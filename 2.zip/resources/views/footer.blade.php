
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <p class="text-center copyright">Copyright 2023, RIMEPLOI, {{__('welcome.All rights reserved')}}©</p>
        </div>
    </div>
</div>


<script src="script.js"></script>
