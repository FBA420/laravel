<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha386-9ndCyUaIbzAi2FUVXJi0CjmCapSmO7SnpJef0686qhLnuZ2cdeRhO02iuK6FUUVM" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" 
    integrity="sha386-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te6Bkz" crossorigin="anonymous"></script>



    <style>
        
input, select, textarea {
    outline: none;
    appearance: unset !important;
    -moz-appearance: unset !important;
    -webkit-appearance: unset !important;
    -o-appearance: unset !important;
    -ms-appearance: unset !important; }
  
  input::-webkit-outer-spin-button, input::-webkit-inner-spin-button {
    appearance: none !important;
    -moz-appearance: none !important;
    -webkit-appearance: none !important;
    -o-appearance: none !important;
    -ms-appearance: none !important;
    margin: 0; }
  
  input:focus, select:focus, textarea:focus {
    outline: none;
    box-shadow: none !important;
    -moz-box-shadow: none !important;
    -webkit-box-shadow: none !important;
    -o-box-shadow: none !important;
    -ms-box-shadow: none !important; }
  
  input[type=checkbox] {
    appearance: checkbox !important;
    -moz-appearance: checkbox !important;
    -webkit-appearance: checkbox !important;
    -o-appearance: checkbox !important;
    -ms-appearance: checkbox !important; }
  
  input[type=radio] {
    appearance: radio !important;
    -moz-appearance: radio !important;
    -webkit-appearance: radio !important;
    -o-appearance: radio !important;
    -ms-appearance: radio !important; }
  
  input[type=number] {
    -moz-appearance: textfield !important;
    appearance: none !important;
    -webkit-appearance: none !important; }
  
  input:-webkit-autofill {
    box-shadow: 0 0 0 30px transparent inset;
    -moz-box-shadow: 0 0 0 30px transparent inset;
    -webkit-box-shadow: 0 0 0 30px transparent inset;
    -o-box-shadow: 0 0 0 30px transparent inset;
    -ms-box-shadow: 0 0 0 30px transparent inset; }
  
.container {
    position: relative;
    margin: 0 auto;
    box-shadow: 0px 10px 9.9px 0.1px rgba(0, 0, 0, 0.1);
    -moz-box-shadow: 0px 10px 9.9px 0.1px rgba(0, 0, 0, 0.1);
    -webkit-box-shadow: 0px 10px 9.9px 0.1px rgba(0, 0, 0, 0.1);
    -o-box-shadow: 0px 10px 9.9px 0.1px rgba(0, 0, 0, 0.1);
    -ms-box-shadow: 0px 10px 9.9px 0.1px rgba(0, 0, 0, 0.1);
    background: #fff; }

.signup-content {
    padding: 10px 0; }
  
  .signup-form {
    padding: 58px 50px 0px 50px;
    height: 455px;
    overflow-y: auto; }
  
  .signup-form::-webkit-scrollbar-track {
    border-radius: 5px;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    -o-border-radius: 5px;
    -ms-border-radius: 5px;
    background-color: #f8f8f8;
    width: 10px; }
  
  .signup-form::-webkit-scrollbar {
    border-radius: 5px;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    -o-border-radius: 5px;
    -ms-border-radius: 5px;
    width: 10px;
    background-color: #fff; }
  
  .signup-form::-webkit-scrollbar-thumb {
    border-radius: 5px;
    -moz-border-radius: 5px;
    -webkit-border-radius: 5px;
    -o-border-radius: 5px;
    -ms-border-radius: 5px;
    background-color: #ebebeb; }
  
    label, input {
        display: block;
        width: 100%; }
      
      label {
        text-transform: uppercase;
        font-weight: 800;
        margin-bottom: 3px; }
      
      input {
        border: 1px solid #ebebeb;
        border-radius: 5px;
        -moz-border-radius: 5px;
        -webkit-border-radius: 5px;
        -o-border-radius: 5px;
        -ms-border-radius: 5px;
        box-sizing: border-box;
        padding: 15px 20px;
        /* font-size: 5px; */
        font-weight: bold;
        font-family: 'Montserrat'; }
        input:focus {
          border: 1px solid #1da0f2; }
        input::-webkit-input-placeholder {
          color: #999;
          text-transform: uppercase;
          font-weight: 600; }
        input::-moz-placeholder {
          color: #999;
          text-transform: uppercase;
          font-weight: 600; }
        input:-ms-input-placeholder {
          color: #999;
          text-transform: uppercase;
          font-weight: 600; }
        input:-moz-placeholder {
          color: #999;
          text-transform: uppercase;
          font-weight: 600; }

.form-flex input + label:first-of-type {
  border-radius: 5px 0 0 5px;
  -moz-border-radius: 5px 0 0 5px;
  -webkit-border-radius: 5px 0 0 5px;
  -o-border-radius: 5px 0 0 5px;
  -ms-border-radius: 5px 0 0 5px;
  border-right: none; }
.form-flex input + label:last-of-type {
  border-radius: 0 5px 5px 0;
  -moz-border-radius: 0 5px 5px 0;
  -webkit-border-radius: 0 5px 5px 0;
  -o-border-radius: 0 5px 5px 0;
  -ms-border-radius: 0 5px 5px 0;
  border-left: none; }

.form-row {
  margin: 0 -11px; }
  .form-row .form-group, .form-row .form-radio {
    width: 50%;
    padding: 0 11px; }

.form-group, .form-radio {
  margin-bottom: 23px;
  position: relative; }

#city {
    z-index: 9; } 
#section{ 
        padding-top: 1rem;
        padding-bottom: 2rem;
        background-color: #f1f3f745;
     
}  

.form-submit {
    width: auto;
    background: #028529da;
    color: #fff;
    text-transform: uppercase;
    font-weight: 900;
    padding: 16px 50px;
    float: right;
    border: none;
    margin-top: 37px;
    cursor: pointer; }
    .form-submit:hover {
      background: #0c85d0; }
      .select-list {
        position: relative;
        display: inline-block;
        width: 100%;
        margin-bottom: 47px; }

        .list-item {
            position: absolute;
            width: 100%; }
    </style>
    <script>
      // formInscrivez.blade.php script starts
    $index = 1;
    $(document).ready(function() {
        var i = 1;
        $('#add').click(function() {
            i++;
            $('#dynamic_field').append('<tr id="row' + i +
                '"><td><input type="file" name="piecejointe[]"  class="form-control name_list" /></td><td><button type="button" name="remove" id="' +
                i + '" class="btn btn-danger btn_remove">X</button></td></tr>');
        });

        $(document).on('click', '.btn_remove', function() {
            var button_id = $(this).attr("id");
            $('#row' + button_id + '').remove();
        });

    });

    $(document).on("click", "#formationBten", function() {
        $index++;
        $('#formation').append('<div class="row" id="form" >' +
            '<div class="col-sm-12"><button type="button" name="remove" class="btn btn-danger formremove" style="float: right;">X</button></div>' +
            '<div class="col-sm-4"><span style="font-weight: 900; "><input type="hidden" class="form-control" name="id_foramtion[]" value="' +
            $index +
            '">  Date Debut</span> <input name="date_debut[]" required type="date" class="form-control">' +
            '</div> <div class="col-sm-4"><span style="font-weight: 900; "> Date Fin </span><input name="date_fin[]" type="date" class="form-control"> </div>' +
            '<div class="col-sm-4"> <span style="font-weight: 900;">Formation en cours</span> <input name="encour_f[]" value="' +
            $index + '" type="checkbox" class="form-control"></div>' +
            '<div class="col-sm-3" style="margin-top: 15px;"><span style="font-weight: 900; "> Titre de formation </span>' +
            '<select name="titre_formation[]" type="text" class="form-control" required>' +
            '<option value="Certificat">Certificat</option><option value="Brevet">Berevet</option>' +
            '<option value="Bac">Bac</option><option value="Bac+2">Bac+2</option>' +
            '<option value="Licence">Licence</option><option value="Bac+4">Bac+4</option>' +
            '<option value="Master">Master</option><option value="Doctorat">Doctorat</option>' +
            '<option value="Autres">Autres</option></select></div>' +
            '<div class="col-sm-3" style="margin-top: 15px;"><span style="font-weight: 900;">Spécialité</span><input name="specialite[]" type="text" class="form-control"></div>' +
            '<div class="col-sm-3" style="margin-top: 15px;"><span style="font-weight: 900; "> Etablissement </span> <input name="etablissement[]" type="text" required class="form-control"></div>' +
            '<div class="col-sm-3" style="margin-top: 15px;"><span style="font-weight: 900;">Ville </span><input name="ville[]" type="text" class="form-control" required></div>' +
            '<div class="col-sm-12" style="margin-top: 15px;"> <textarea class="form-control" name="description_formation[]" id="form6Example7" rows="4" cols="54" placeholder="Saisire une descrition detaillee de votre formation"></textarea><br></div></div><br>'
        )

    });

    $(document).on("click", "#experBtn", function() {
        $index++;
        $('#experiance').append('<div class="row" id="exper" >' +
            '<div class="col-sm-12 text-right"><button type="button" name="remove" id="expremove" class="btn btn-danger">X</button></div>' +

            '<div class="col-sm-4"> <span style="font-weight: 900; ;"> Date Debut </span> <input type="hidden" class="form-control" name="id_experience[]" value="' +
            $index + '"> <input name="date_debit[]" type="date" class="form-control" > </div>' +
            '<div class="col-sm-4"> <span style="font-weight: 900; "> Date Fin </span> <input name="date_fin_Exp[]" type="date" class="form-control"></div>' +
            '<div class="col-sm-4"> <span style="font-weight: 900; ">Experience en cours</span> <input name="encour_e[]" value="' +
            $index + '" type="checkbox" class="form-control"></div>' +

            '<div class="col-sm-6" style="margin-top: 15px;"> <span style="font-weight: 900;"> Titre d\'experience </span> <input name="titre_projet[]" type="text"  class="form-control"> </div>' +
            '<div class="col-sm-6" style="margin-top: 15px;"> <span style="font-weight: 900;"> Nom d\'etablissement </span> <input name="nom_entreprise[]"  type="text" class="form-control"></div>' +

            '<div class="col-sm-12" style="margin-top: 15px;"><textarea class="form-control" name="description_experience[]" id="form6Example7" rows="4" cols="54" placeholder="Saisire une descrition detaillee de votre experience"></textarea><br></div>' +
            '</div><br>')
    });

    $(document).on("click", "#addLangue", function() {
        $index++;
        $('#langue').append('<div class="row" id="form">' +
            '<div class="col-sm-12 text-right"><br><button type="button" name="remove"  class="btn btn-danger formremove" ">X</button></div>' +
            '<div class="col-md-6"><span style="font-weight: 900;">Langue</span>' +
            '<select required="true" name="nom_langue[]" class="form-control"><option value=""></option>' +
            '<option value="Arabe">Arabe </option><option value="Français">Français </option>' +
            '<option value="Anglais">Anglais </option>' +
            '<option value="Espagnol">Espagnol </option><option value="Chinois">Chinois </option>' +
            '<option value="Russe">Russe </option><option value="Allemand">Allemand </option>' +
            '</select></div><div class="col-md-6"><span style="font-weight: 900;">Niveau</span><select required="true" name="niveau_langue[]" class="form-control">' +
            '<option value=""> </option> <option value="Excellent">Excellent </option> <option value="Bien">Bien </option>' +
            '<option value="Moyen">Moyen </option><option value="Débutant">Débutant </option>' +
            '</select></div> </div>'
        )
    });

    $(document).on("click", "#addSkills", function() {
        $index++;
        $('#skills').append('<div class="row" id="form">' +
            '<div class="col-sm-12 text-right"><br><button type="button" name="remove"  class="btn btn-danger formremove" ">X</button></div>' +
            '<div class="col-md-6"> <span style="font-weight: 900;">Compétences</span>' +
            '<input type="text" name="skills_nom[]" class="form-control"> </div> <div class="col-md-6"> <span style="font-weight: 900;">Niveau</span>' +
            '<select required="true" name="niveau_skills[]" class="form-control"> <option value=""> </option> <option value="90">Excellent</option>' +
            '<option value="75">Bien</option> <option value="50">Moyen</option> <option value="15">Débutant</option>' +
            '</select> </div> </div>'
        )
    });

    $(document).on('click', '#expremove', function() {
        $(this).closest("#exper").remove();
    });

    $(document).on('click', '.formremove', function() {
        $(this).closest("#form").remove();
    });

    $(document).on('click', '#retireImg', function() {
        $("#img").html('<img src="https://rimtic.com/cvtheque/images/profile.png">' +
            '<input type="file" name="image" class="form-control" />');

    });
    $(document).on('click', '#retireCV', function() {
        $("#cv").html('<table class="" id="dynamic_field" style="width: 100%;">' +
            '<tr> <td style="width: 100%;">' +
            '<input required="true" type="file" name="piecejointe[]" class="form-control name_list" />' +
            '</td> </tr> </table>');
    });
// formInscrivez.blade.php script ends

// signup.blade.php starts
        $(document).ready(function() {
            /*$('body').bind('copy', function (e) {
        e.preventDefault();
    });
   
    $("body").on("contextmenu",function(e){
        return false;
    });*/

            $('#appOff').click(function(e) {
                $(this).css("backgroundColor", "#ad081f");
                $('.p11').css("backgroundColor", "#f1efef");
                $('.p132').css("backgroundColor", "#f1efef");
                $('.emploi').css("color", "black");
                $('.appels').css("color", "white");
                $('.publi').css("color", "black");
                $('#tab-content').css("border-color", "#ad081f");
            });
            $('#offEmp').click(function(e) {
                $(this).css("backgroundColor", "#255025");
                $('.p12').css("backgroundColor", "#f1efef");
                $('.p132').css("backgroundColor", "#f1efef");
                $('.appels').css("color", "black");
                $('.emploi').css("color", "white");
                $('.publi').css("color", "black");
                $('#tab-content').css("border-color", "#255025");
            });
            $('#publi').click(function(e) {
                $(this).css("backgroundColor", "#594c06");
                $('.p12').css("backgroundColor", "#f1efef");
                $('.p11').css("backgroundColor", "#f1efef");
                $('.appels').css("color", "black");
                $('.emploi').css("color", "black");
                $('.publi').css("color", "white");
                $('#tab-content').css("border-color", "#594c06");
            });

        });
  // signup.blade.php ends
    </script><?php /**PATH D:\xampp1\htdocs\rimtic\resources\views/css.blade.php ENDPATH**/ ?>