<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
     <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="c-l-heading">
                    <h5>Modèles de lettres de motivation à téléchager</h5>
                </div>
            </div>
        </div>
     </div>
     <div class="container">
        <div class="row">
            <div class="col-md-12">
               <div class="c-l-container">
                  <div class="c-l-box">
                    <a class="letter-link" href="<?php echo e(route('download-file')); ?>">Download file</a>
                  </div>
                  <div class="c-l-box">
                    <a class="letter-link" href="">Lettre de motivation - acheteur</a>
                  </div>
                  <div class="c-l-box">
                    <a class="letter-link" href="">Lettre de motivation - acheteur</a>
                  </div>
               </div>
            </div>
        </div>
     </div>
     <div class="container">
        <div class="row">
           <div class="col-md-12">
                 <p class="copyright">Copyright 2018, RIMTIC, Tous droits réservés ©</p>
           </div>
        </div>
     </div><?php /**PATH D:\xampp1\htdocs\rimtic\resources\views/coverletter.blade.php ENDPATH**/ ?>