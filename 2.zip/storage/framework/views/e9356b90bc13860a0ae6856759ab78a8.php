<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Rimimploi</title>
      <!-- Bootstrap CSS v5.2.1 -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
<!-- jQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Bootstrap JS v5.2.1 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>

      <!-- Font Awesome -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
  <!-- Stylesheet -->
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
</head>
<body>
    <div class="header">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="logo"> <img src="<?php echo e(asset('images/logo.png')); ?>" height="150px" alt=""></div>
            </div>
        </div>
    </div>
  <nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
      <!-- Toggler button in center -->
      <button class="navbar-toggler navbar-toggler-center nav-toggle-btn" type="button" data-bs-toggle="collapse"
      data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span><i class="fas fa-bars nav-toggle-icon"></i></span>
    </button>
      </button>

      <!-- Navigation items -->
      <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="#">Item 1</a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown1" role="button" data-bs-toggle="dropdown"
              aria-expanded="false">
              Item 2
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
              <li><a class="dropdown-item" href="#">Subitem 1</a></li>
              <li><a class="dropdown-item" href="#">Subitem 2</a></li>
              <li><a class="dropdown-item" href="#">Subitem 3</a></li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown2" role="button" data-bs-toggle="dropdown"
              aria-expanded="false">
              Item 3
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown2">
              <li><a class="dropdown-item" href="#">Subitem 1</a></li>
              <li><a class="dropdown-item" href="#">Subitem 2</a></li>
              <li><a class="dropdown-item" href="#">Subitem 3</a></li>
            </ul>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown3" role="button" data-bs-toggle="dropdown"
              aria-expanded="false">
              Item 4
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown3">
              <li><a class="dropdown-item" href="#">Subitem 1</a></li>
              <li><a class="dropdown-item" href="#">Subitem 2</a></li>
              <li><a class="dropdown-item" href="#">Subitem 3</a></li>
            </ul>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Item 5</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Item 6</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Item 7</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</div>
</body>
</html>
<?php /**PATH D:\xampp1\htdocs\rimtic\resources\views/header.blade.php ENDPATH**/ ?>