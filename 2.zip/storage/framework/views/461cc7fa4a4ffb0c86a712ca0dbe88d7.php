<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RIM EMPLOI</title>
      <!-- Bootstrap CSS v5.2.1 -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-iYQeCzEYFbKjA/T2uDLTpkwGzCiq6soy8tYaI1GyVh/UjpbCx/TYkiZhlZB6+fzT" crossorigin="anonymous">
<!-- jQuery -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

<!-- Bootstrap JS v5.2.1 -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>

      <!-- Font Awesome -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
  <!-- Stylesheet -->
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  
  <link rel="shortcut icon" href="<?php echo e(asset('images/Rlogo.png')); ?>" type="image/x-icon">
  <script src="https://cdn.tiny.cloud/1/vquc8ac0climskz6vbsylev20x9jvihyrcbb7ipbl28lb6f0/tinymce/5/tinymce.min.js"></script>
</head>
<body>
    <div class="header">
    <div class="container-fluid">
      <?php $__currentLoopData = $head; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
            <div class="col-md-3 p-3">
                <div><center><img class="logo" src="/images/<?php echo e($head->logo); ?>"  height="120px" alt="logo"></center> </div>
            </div>
            <div class="col-md-6">
              <div ><img src="/images/<?php echo e($head->add); ?>" width="100%" height="120px" alt=""></div>
          </div>
          <div class="col-md-3 p-3">
            <div> <center><img class="logo" src="/images/<?php echo e($head->logo); ?>"  height="120px" alt="logo"></center></div>
        </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="col-md-12 mt-3">
      <h5 class="text-center" style="color: #233a94"><b>المنصة الرائدة في موريتانيا لتوفير فرص العمل ومتابعة الأخبار الاقتصادية</b></h5>
     <center> <img src="/images/header1.jpg"  alt="Logo"></center>
    </div>
  <nav class="navbar navbar-expand-lg navbar-light">
    <div class="container">
      <!-- Toggler button in center -->
      <button class="navbar-toggler navbar-toggler-center nav-toggle-btn" type="button" data-bs-toggle="collapse"
      data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span><i class="fas fa-bars nav-toggle-icon"></i></span>
    </button>
      </button>
      <!-- Navigation items -->
      <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item mt-4">
            <a class="nav-link" href="/"><?php echo e(__('welcome.Welcome')); ?></a>
          </li>
          <li class="nav-item mt-4 dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php echo e(__('welcome.Companies')); ?>

            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown1">
              <li><a class="dropdown-item" href="/job-offer-form"><?php echo e(__('welcome.Submit a job offer')); ?></a></li>
              <li><a class="dropdown-item" href="/tender-form"><?php echo e(__('welcome.Submit a call for tenders')); ?></a></li>
              <li><a class="dropdown-item" href="/review-form"><?php echo e(__('welcome.Leave a review')); ?></a></li>
              <li><a class="dropdown-item" href="/article"><?php echo e(__('welcome.HR Solutions')); ?></a></li>
            </ul>
          </li>
          <li class="nav-item mt-4 dropdown ">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php echo e(__('welcome.Candidates')); ?>

            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown2">
              <li><a class="dropdown-item" href="/cv-form"><?php echo e(__('welcome.Submit your resume')); ?></a></li>
            </ul>
          </li>
          <li class="nav-item mt-4 dropdown ">
            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <?php echo e(__('welcome.Models')); ?>

            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="/cv"><?php echo e(__('welcome.CVs')); ?></a></li>
              <li><a class="dropdown-item" href="/letter"><?php echo e(__('welcome.Letters of motivation')); ?></a></li>
            </ul>
          </li>
          <li class="nav-item mt-4">
            <a class="nav-link " href="/contact-form"><?php echo e(__('welcome.Contact')); ?></a>
          </li>
          <li class="nav-item mb-2">
            <a class="nav-link" href="#"><img class="pro-gif" src="/images/pro.gif"  width="100%" height="80px" alt="Logo"> </a>
          </li>
          <li class="nav-item mt-4 dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <?php echo e(__('welcome.Select Language')); ?>

                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="locale/fr">French</a>
                        <a class="dropdown-item" href="locale/ar">Arabic</a>
                        <a class="dropdown-item" href="locale/en">English</a>
                    </div>
          </li>
          <li>            
            <?php if(Route::has('login')): ?>
            <div class="sm:fixed sm:top-0 sm:right-0 p- text-right z-10">
                <?php if(auth()->guard()->check()): ?>
                <li class="nav-item mt-4">
                  <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500"><?php echo e(__('welcome.Profile')); ?></a></li>
                <?php else: ?>
                <li class="nav-item mt-4"><a class="nav-link" href="<?php echo e(route('login')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500"><?php echo e(__('welcome.Log in')); ?></a></li>
                    <?php if(Route::has('register')): ?>
                <li class="nav-item mt-4"><a class="nav-link" href="<?php echo e(route('register')); ?>" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500"><?php echo e(__('welcome.Register')); ?></a></li>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
            <?php endif; ?>
          </li>
        </ul>
      </div>
    </div>
  </nav>
</div>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/header.blade.php ENDPATH**/ ?>