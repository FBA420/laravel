<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if(Session::has('success')): ?>
    <div class="alert alert-success text-center">
        <?php echo e(Session::get('success')); ?>

    </div>
<?php endif; ?>
<div style="margin-top: 20px;">
<div >
<div class="container">
    <div class="row bg-light">
        <div class="col-sm-12">
            <center>
                <h3 style="font-weight: 900; padding: 10px; "><?php echo e(__('welcome.Submit your resume')); ?></h3>
            </center>
        </div>
    </div>
<br>
<div class="bg-light p-4">
<form action="<?php echo e(url('cvform')); ?>" method="post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <div class="container">
    <div class="row">
      <div class="col-sm-6">
        <label for="name"><?php echo e(__('welcome.NAME')); ?></label>
        <input required type="text" class="form-control" name="name" id="name">
      </div>
      <div class="col-sm-6">
        <label for="contact"><?php echo e(__('welcome.Contact')); ?></label>
        <input required type="number" class="form-control" name="contact" id="contact">
      </div>
    </div>
    <div class="row">
      <div class="col-sm-6">
        <label for="age"><?php echo e(__('welcome.AGE')); ?></label>
        <input required type="number" class="form-control" name="age" id="age" required>
      </div>
      <div class="col-sm-6">
        <label for="qualification"><?php echo e(__('welcome.Qualification')); ?></label>
        <input required type="text" class="form-control" name="qualification" id="qualification" required>
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12">
        <label for="field"><?php echo e(__('welcome.Field of Study')); ?></label>
        <input required type="text" class="form-control" name="field" required>
      </div>
      <div class="col-sm-12">
        <label class="fontAlmari form-label"><?php echo e(__('welcome.Candidate Image')); ?></label>
        <input required type="file" name="image" class="form-control">
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12">
        <label class="fontAlmari form-label"><?php echo e(__('welcome.Upload CV in PDF')); ?></label>
        <input required type="file" name="cvfile" class="form-control">
      </div>
      <div class="col-sm-12">
        <label class="fontAlmari form-label"><?php echo e(__('welcome.Upload CV in JPG')); ?></label>
        <input required type="file" name="cvpic" class="form-control">
      </div>
    </div>
    <div class="row">
      <div class="col-sm-12">
        <label class="fontAlmari form-label"><?php echo e(__('welcome.Upload Letter in PDF')); ?></label>
        <input required type="file" name="letter" class="form-control">
      </div>
    </div>
    <div class="row" style="margin-top: 30px;">
      <div class="col-sm-12 text-center">
        <button type="submit" class="btn btn-success btn-lg" ><?php echo e(__('welcome.Submit')); ?></button>
      </div>
    </div>
  </div>
</form>
</div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 





<?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/cvform.blade.php ENDPATH**/ ?>