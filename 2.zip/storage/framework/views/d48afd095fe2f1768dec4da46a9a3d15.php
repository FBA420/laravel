<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<div class="container">
    <button type="button" disabled="" class="btn btn-dark btn-lg btn-block fontAlmari btn btn-primary"
    style="margin-top: 15px; margin-bottom: 10px; color: rgb(255, 255, 255); width: 100%;">
    Vous pouvez nous envoyer votre avis sur 
    <span style="font-weight: bold;">contact@rimemploi.com</span>
</button>  
          <!-- row having bottom and top lines -->
    <div>
        <p class="fontAlmari" style="border-width: 2px 0px; border-top-style: solid; border-right-style: initial; border-bottom-style: solid; border-left-style: initial; border-color: black; border-image: initial; text-align: center; font-size: 25px; padding: 5px;">
        Déposer une offre d'emploi</p>
    </div>
</div>
<div class="container">
    <form action="<?php echo e(url('joboffer')); ?>" method="post" enctype="multipart/form-data">
 <?php echo csrf_field(); ?>
<div>
    <div class="row" style="margin: 15px 1px 0px; background: rgb(238, 238, 238); padding-bottom: 10px;">
    <div class="col-sm-4 col-12">
        <label class="fontAlmari form-label">Société</label>
        <input type="text" hidden="" value="0">
        <input type="text" name="company" class="form-control">
        <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
    </div>
    <div class="col-sm-4 col-12">
        <label class="fontAlmari form-label">Logo</label>
        <input type="file" name="logo"  class="form-control">
    </div>
    <div class="col-sm-4 col-12">
        <label class="fontAlmari form-label">Ville</label>
        <input type="text" name="city"  class="form-control" value="">
        <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
    </div>
    </div>
    <div class="row" style="margin: 10px 0px 5px;">
<div class="col-sm-9 col-12">
    <label class="fontAlmari form-label">Titre</label>
    <input type="text" name="title"  class="form-control">
    <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
</div>
<div class="col-sm-3 col-12">
    <label class="fontAlmari form-label">Date limite de candidature</label>
    <input type="date" name="deadline"  class="form-control">
    <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
</div>

<div class="col-sm-12 col-12">
    <label class="fontAlmari form-label">Discription</label>
    <textarea class="form-control" name="description" id="" cols="30" rows="10"></textarea>
    <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
</div>
<div class="col-sm-12 col-12" style="margin-top: 50px;">
 <div class="row">
 <div class="col-sm-12 col-12" style="margin: 10px 0px 5px;">
 <p class="fontAlmari" style="font-weight: bold; color: black;">Autres informations : </p>
 </div>
 <div class="col-lg-4 col-12">
 <label class="fontAlmari form-label">Domaine</label>
 <select name="domaine" aria-label="Default select example" class="fontAlmari form-select">
 <option value=""></option>
 <option name="domaine" value="autres">Autres</option>
 <option name="domaine" value="ressource">Ressources Humaines</option>
 <option name="domaine" value="commercial">Commercial, vente, Marketing</option>
 <option name="domaine" value="informatique">Informatique et Technologie de l’information</option>
 <option name="domaine" value="transport">Transport, Logistique</option>
 <option name="domaine" value="maintenance">Maintenance et Réparation</option>
 <option name="domaine" value="tourisme">Tourisme, hôtellerie, restauration</option>
 <option name="domaine" value="gestion">Gestion, Finance, Comptabilité</option>
 <option name="domaine" value="environement">Environnement et Développement durable</option>
 <option name="domaine" value="securite">Sécurité</option>
 <option name="domaine" value="sante">Santé et social</option>
 <option name="domaine" value="secretriat">Secretariat, assistanat</option>
 <option name="domaine" value="nutrition">Nutrition, Elévage, Agriculture</option>
 <option name="domaine" value="langue">Langues, Traduction, Littéraire</option>
 <option name="domaine" value="electricite_enrgie">Electricité, Enérgie, Mécanique, Automatisme</option>
 <option name="domaine" value="chimie_bio">Chimie, Biologie</option>
 <option name="domaine" value="genie_civil">Génie Civil, BTP</option>
 <option name="domaine" value="banque">Banque et Assurance</option>
 </select>
 <p class="fontAlmari" style="font-size: 12px; color: red;">
 </p>
 </div>
 <div class="col-lg-4 col-12">
 <label class="fontAlmari form-label">Niveau d'étude demandé</label>
 <select name="qualification" aria-label="Default select example" class="fontAlmari form-select">
 <option name="qualification" value=""></option>
 <option name="qualification" value="sans">Sans</option>
 <option name="qualification" value="primaire">Primaire</option>
 <option name="qualification" value="brevet">brevet</option>
 <option name="qualification" value="Bac">Bac</option>
 <option name="qualification" value="Bac_2">Bac+2</option>
 <option name="qualification" value="Bac_3">Bac+3</option>
 <option name="qualification" value="Bac_4">Bac+4</option>
 <option name="qualification" value="Bac_5">Bac+5</option>
 <option name="qualification" value="doctorat">Doctorat</option>
 <option name="qualification" value="autres">Autres</option>
 </select>
 <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
 </div>
 <div class="col-lg-4 col-12">
 <label class="fontAlmari form-label">Années d'expérience</label>
 <select name="experience" aria-label="Default select example" class="fontAlmari form-select">
    <option value=""></option>
    <option name="experience" value="-">-</option>
    <option name="experience" value="0">0</option>
    <option name="experience"  value="1">1</option>
    <option name="experience" value="2">2</option>
    <option name="experience" value="3">3</option>
    <option name="experience" value="4">4</option>
    <option name="experience" value="5">5</option>
    <option name="experience" value="6">6</option>
    <option name="experience" value="7">7</option>
    <option name="experience" value="8">8</option>
    <option name="experience" value="9">9</option>
    <option name="experience" value="10">10</option>
    <option name="experience" value="11">11</option>
    <option name="experience" value="12">12</option>
    <option name="experience" value="13">13</option>
    <option name="experience" value="14">14</option>
    <option name="experience" value="15">15</option>
</select>
<p class="fontAlmari" style="font-size: 12px; color: red;"></p></div></div></div></div>
 <table class="table">
    <tbody>
        <tr>
            <td style="width: 80%;">
            <input type="file" name="file" class="form-control"> 
        </td>
        <td>
 <button type="button" class="btn btn-success fontAlmari btn btn-primary" style="background: none; color: black; width: 80%;"> Autres fichiers</button>
</td>
</tr>
</tbody>
</table>
<div style="text-align: center;">
 <button type="submit" value="submit" class="btn btn-success fontAlmari btn btn-primary" style="width: 190px; background: green; color: rgb(255, 255, 255);">Valider</button>
    </div>
</div>

<div>
<p class="fontAlmari" 
style="text-align: center; color: red; font-size: 12px;">Copyright 2023, RIM EMPLOI, Tous droits réservés ©</p>
</div>
    </form>
</div>
</body>
</html>


<?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/form.blade.php ENDPATH**/ ?>