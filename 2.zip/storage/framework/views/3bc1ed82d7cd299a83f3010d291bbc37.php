
  <a href="/adminhome">Dashboard</a>
  <a href="<?php echo e(url('/users')); ?>">Users</a>
  <a href="<?php echo e(url('/cvpic')); ?>">ADD CV Image</a>
  <a href="<?php echo e(url('/cvdata')); ?>">CVs Data</a>
  <a href="<?php echo e(url('/joboffer')); ?>">Job Offers</a>
  <a href="<?php echo e(url('/tenders')); ?>">Tenders</a>
  <a href="<?php echo e(url('/review')); ?>">Review</a>
  <a href="<?php echo e(url('/contact')); ?>">Contact</a>
  <a href="<?php echo e(url('/interview')); ?>">Interview</a>
  <button class="dropdown-btn">Website
    <i class="fas fa-caret-down"></i>
  </button>
  <div class="dropdown-container">
    <a href="<?php echo e(url('/information')); ?>">Edit Contact Information</a>
    <a href="<?php echo e(url('/header')); ?>">Edit Header</a>
    <a href="<?php echo e(url('/footer')); ?>">Edit Footer</a>
    <a href="<?php echo e(url('/advertisement')); ?>">Add Advertisment</a>
  </div>
 <?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/admin/admindb.blade.php ENDPATH**/ ?>