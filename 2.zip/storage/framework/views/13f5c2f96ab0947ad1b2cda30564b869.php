<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
     <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="c-l-heading">
                    <h5>Modèles de CVs à téléchager</h5>
                </div>
            </div>
        </div>
     </div>
     <div class="container">
        <div class="row">
<?php
include ('connection.php');
$sql = "SELECT * FROM form";
$result = mysqli_query($con,$sql);   
     while ($row = mysqli_fetch_assoc($result)) {
     ?>
     <div class="col-md-3">
      <p  class="cv-name"><?php echo $row['name'];?></p>
     <img src="./images/<?php echo $row['image'];?>" width="250px" height="300px"><br><br>
     </div>    
    <?php
}
?>
    </div>
     </div>
     <div class="container">
        <div class="row">
           <div class="col-md-12">
                 <p class="copyright">Copyright 2018, RIMTIC, Tous droits réservés ©</p>
           </div>
        </div>
     </div>
</body>
</html><?php /**PATH D:\xampp1\htdocs\rimtic\resources\views/cv.blade.php ENDPATH**/ ?>