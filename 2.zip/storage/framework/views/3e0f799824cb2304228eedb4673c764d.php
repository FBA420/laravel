<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
   <div class="container-fluid mt-5">
    <div class="row">
        <div class="col-md-4">
            <div class="form-links">
                <a href="#">Déposer une offre d'emploi</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-links">
                <a href="#">Déposer une offre d'emploi</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-links">
                <a href="#">Déposer une offre d'emploi</a>
            </div>
        </div>
    </div>
   </div>
<div class="home-data-bg">
      <div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
            <div class="data-show">
                <button onclick="showContainer(1)" class="button-link">Button 1</button>
            </div>
        </div>
        <div class="col-md-4">
            <div class="data-show">
                <button onclick="showContainer(2)" class="button-link">Button 2</button>
            </div>
        </div>
        <div class="col-md-4">
            <div class="data-show">
                <button onclick="showContainer(3)" class="button-link">Button 3</button>
            </div>
        </div>
    </div>
   </div>
   <div id="container1" class="data-container job-box">
   <div class="container-fluid">
    <div class="row">
        <div class="col-md-4 jobs-container">
           <div class="job-offer-div">
              <div class="job-img">
                <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" width="100%" height="auto" alt="">
             </div>
             <div class="job-text">
                <a href="<?php echo e(url('/visit')); ?>" >Directeur des Ressources Humaines</a>
                <div class="job-info">
                    <p class="job-location"><i class="fas fa-map-marker-alt job-l-color"></i>Tasiasit</p>
                      <p class="job-views"> <i class="fas fa-eye job-l-color eye"></i> 260</p>
                      <p class="job-date f-clock-color"> <i class="fas fa-clock fa-spin fa-xs f-clock-color"></i>6-6-2023</p>
                </div>
                <div class="container-j">
                    <div class="content">
                      <p><i class="fas fa-building fa-xs f-b-color"></i>This is  side.</p>
                    </div>
                    <div class="button-toggle">
                      <button onclick="toggleContent()" class="btn-togle"><i class="fas fa-bars toggle-icon"></i></button>
                    </div>
                  </div>
                  <div id="toggleDiv" class="toggle-content">
                    <div class="toggle-container">
                        <div class="toggle-text">
                          <p>sjf</p>
                        </div>
                        <div class="toggle-text">
                          <p>dfj</p>
                        </div>
                        <div class="toggle-text">
                          <p>lwewe</p>
                        </div>
                    </div>
                  </div>
             </div>
           </div>
          </div>
    </div>
   </div>
   </div>
   <div id="container2" class="data-container job-box">
    <div class="container-fluid">
      <div class="row">
          <div class="col-md-4 jobs-container">
             <div class="job-offer-div">
                <div class="job-img">
                  <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" width="100%" height="auto" alt="">
               </div>
               <div class="job-text">
                  <a href="<?php echo e(url('/visit')); ?>" >Directeur des Ressources Humaines</a>
                  <div class="job-info">
                      <p class="job-location"><i class="fas fa-map-marker-alt job-l-color"></i>Tasiasit</p>
                      <div class="views-date-container">
                        <p class="job-views"> <i class="fas fa-eye job-l-color"></i> 260 <i class="fas fa-clock fa-spin fa-xs f-clock-color"></i></p>
                        <p class="job-date f-clock-color">6-6-2023</p>
                      </div>
                  </div>
                  <div class="container-j">
                      <div class="content">
                        <p><i class="fas fa-building fa-xs f-b-color"></i>This is  side.</p>
                      </div>
                    </div>
               </div>
             </div>
            </div>
      </div>
     </div>
   </div>
  </div>
   <div id="container3" class="data-container job-box">
    <div class="container-fluid">
      <div class="row">
          <div class="col-md-4 jobs-container">
             <div class="job-offer-div">
                <div class="job-img">
                  <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" width="100%" height="auto" alt="">
               </div>
               <div class="job-text">
                  <a href="<?php echo e(url('/visit')); ?>" >Directeur des Ressources Humaines</a>
                  <div class="job-info">
                      <div class="views-date-container">
                        <p class="job-views"> <i class="fas fa-eye job-l-color"></i> 260 <i class="fas fa-clock fa-spin fa-xs f-clock-color"></i></p>
                        <p class="job-date f-clock-color">6-6-2023</p>
                      </div>
                  </div>
                  <div class="container-j">
                      <div class="content">
                        <p><i class="fas fa-building fa-xs f-b-color"></i>This is.</p>
                      </div>
                  </div>
               </div>
             </div>
          </div>
      </div>
     </div>
   </div>
  </div>
  <div class="home-data-bg pt-3">
   <div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
            <div class="form-links">
                <a href="#">Déposer une offre d'emploi</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-links">
                <a href="#">Déposer une offre d'emploi</a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-links">
                <a href="#">Déposer une offre d'emploi</a>
            </div>
        </div>
    </div>
  </div>
  <div class="container-fluid">
    <div class="row">
      <div class="col-md-4">
         <div class="cvs-container">
          <div class="cvs-img">
            <img src="<?php echo e(asset('images/logo.png')); ?>" width="100%" height="100%" alt="">
          </div>
          <div class="cvs-text">
            <h6>Study level: <span class="cv-t-s"> </span></h6>
            <h6>
                Field of study: <span class="cv-t-s"> </span>
            </h6>
            <h6>
              Age: <span class="cv-t-s"> </span>
            </h6>
            <h6>Nom: <span class="cv-t-s"> </span></h6>
            <h6>
              Contact:<span class="cv-t-s"> </span>
            </h6>
          </div>
         </div>
      </div>
    </div>
  </div>
</div>
<div>

   <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<script>
   function toggleContent() {
    var toggleDiv = document.getElementById('toggleDiv');
    toggleDiv.classList.toggle('show');
  }
</script>
  <script>
    function showContainer(containerNumber) {
      // Hide all containers
      var containers = document.getElementsByClassName('data-container');
      for (var i = 0; i < containers.length; i++) {
        containers[i].style.display = 'none';
      }

      // Show the selected container
      var container = document.getElementById('container' + containerNumber);
      container.style.display = 'block';
    }
  </script>

<?php /**PATH D:\xampp1\htdocs\rimtic\resources\views/home.blade.php ENDPATH**/ ?>