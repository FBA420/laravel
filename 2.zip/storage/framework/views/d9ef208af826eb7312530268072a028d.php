  <?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="container" style="margin-top: 20px;">
            <div class="row" style="text-align: center; margin-bottom: 10px;">
                <div style="font-weight:bold;">
                    <span id="sp_1"><?php echo e(__('welcome.Welcome')); ?></span>
                    <span id="sp_2">&nbsp;<?php echo e(__('welcome.YOUR RECRUITMENT CABINET IN MAURITANIA')); ?></span>
                </div>
            </div>
            <div class="row">
                <p class="mul_para">
                    <span >
                        <span style="color: rgb(184, 49, 47);">RIM EMPLOI&nbsp;</span><?php echo e(__('welcome.accompanies its partners in their recruitment process, from searching for the best profiles to the integration of the chosen candidate')); ?>.&nbsp;
                    </span>
                </p>
    <div class="row" style="margin-top:30px;">
        <div class="col-sm-4 d-flex align-items-center justify-content-center">
            <span class="sp_3"><?php echo e(__('welcome.Since 2023, we have developed our business and now have strong partners in many sectors of activity.')); ?>.</span>
        </div>
        <div class="col-sm-4 d-flex align-items-center justify-content-center">
           <center>
            <img src="/images/Rlogo.png" id="img_mid" alt="Logo">
           </center>
        </div>
        <div class="col-sm-4 d-flex align-items-center justify-content-center">
        <span class="sp_3" <img src="#" id="img_mid">
           <?php echo e(__('welcome.As a generalist recruitment agency, we operate in all sectors of activity and for all types of positions with companies of all sizes: large international groups or local companies.')); ?>

        </span>
        </div>
   </div>
    <p><br></p>
    
    <p class="mul_para"><br></p>
    <p style="text-align: center;"><span class="fnt_fm"><span style="color: rgb(184, 49, 47);"><strong>RIM EMPLOI</strong></span><strong>&nbsp; <?php echo e(__('welcome.is your privileged human resources partner')); ?></strong></span></p>
    <p class="mul_para"><br> </p>
    <p class="mul_para"><span class="fnt_fm" ><?php echo e(__('welcome.As a leader in temporary work and recruitment in Mauritania, we leverage our professional expertise.')); ?> <span style="color: rgb(184, 49, 47);">RIM EMPLOI &nbsp;</span><?php echo e(__('welcome.We provide you with a range of customized services')); ?></span></p>
    <p class="mul_para"><br> </p>
    <p class="mul_para"><span class="fnt_fm" ><?php echo e(__('welcome.Based on your challenges and current needs,')); ?> <span style="color: rgb(184, 49, 47);">RIM EMPLOI &nbsp;</span><?php echo e(__('welcome.we offer tailored human resources solutions.')); ?></span></p>
    <p class="mul_para"><br> </p>
    <p class="mul_para"><span class="fnt_fm" ><span style="color: rgb(184, 49, 47);">RIM EMPLOI&nbsp;</span> <?php echo e(__('welcome.It accompanies its partners in their recruitment processes, from searching for the best profiles to the integration of the chosen candidate.')); ?> &nbsp;</span></p>
</div>
        </div>
    </div>
    <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>

<?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/solution.blade.php ENDPATH**/ ?>