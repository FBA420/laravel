<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
     <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="c-l-heading">
                    <h5> <?php echo e(__('welcome.Cover letter templates to download')); ?></h5>
                </div>
            </div>
        </div>
     </div>
     <div class="container">
        <div class="row">
            <div class="col-md-12">
               <div class="c-l-container">
               <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="c-l-box">
                         <a class="letter-link" href="/pdffiles/<?php echo e($data3->letter); ?>" download><i class="fas fa-download dl"></i>Letter Of Motivation</a>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </div>
            </div>
        </div>
     </div>
     <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/coverletter.blade.php ENDPATH**/ ?>