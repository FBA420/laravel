<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
  <div class="bg-dark text-center p-4 admin-h"><h1 class="admin-h">ADMIN DASHBOARD</h1></div>
   <div class="main-div">
  <div class="sidebar">
    <?php echo $__env->make('admin.admindb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
   <!-- Page content -->
<div class="content">
    <div class="col md-8 text-light bg-dark p-4">
        <h3 class="text-center">Enter Interview Article</h3>
         <form action="<?php echo e(url('/uploadinterview')); ?>" method="post" enctype="multipart/form-data">
             <?php echo csrf_field(); ?>
             <div class="mb-3">
              <label for="" class="form-label">Main Heading:</label>
              <input type="text" name="heading" id="" class="form-control" >
            </div>
            <div class="mb-3">
             <label for="" class="form-label">Sub Heading1:</label>
             <input type="text" name="head1" id="" class="form-control"  >
            </div>
            <div class="mb-3">
             <label for="" class="form-label">Paragraph1:</label>
             <textarea name="para1" class="form-control"  id="" cols="30" rows="10"></textarea>
            </div> 
            <div class="mb-3">
              <label for="" class="form-label">image1:</label>
              <input type="file" name="img1" id="" class="form-control" >
             </div> 
             <div class="mb-3">
              <label for="" class="form-label">Sub Heading2:</label>
              <input type="text" name="head2" id="" class="form-control"  >
             </div>
             <div class="mb-3">
              <label for="" class="form-label">Paragraph2:</label>
              <textarea name="para2" class="form-control"  id="" cols="30" rows="10"></textarea>
             </div> 
             <div class="mb-3">
               <label for="" class="form-label">image2:</label>
               <input type="file" name="img2" id="" class="form-control" >
              </div> 
              <div class="mb-3">
                <label for="" class="form-label">Sub Heading3:</label>
                <input type="text" name="head3" id="" class="form-control"  >
               </div>
               <div class="mb-3">
                <label for="" class="form-label">Paragraph3:</label>
                <textarea name="para3" class="form-control"  id="" cols="30" rows="10"></textarea>
               </div> 
               <div class="mb-3">
                 <label for="" class="form-label">image3:</label>
                 <input type="file" name="img3" id="" class="form-control" >
                </div> 
                <div class="mb-3">
                  <label for="" class="form-label">Sub Heading4:</label>
                  <input type="text" name="head4" id="" class="form-control"  >
                 </div>
                 <div class="mb-3">
                  <label for="" class="form-label">Paragraph4:</label>
                  <textarea name="para4" class="form-control"  id="" cols="30" rows="10"></textarea>
                 </div> 
                 <div class="mb-3">
                   <label for="" class="form-label">image4:</label>
                   <input type="file" name="img4" id="" class="form-control" >
                  </div> 
                  <div class="mb-3">
                    <label for="" class="form-label">Sub Heading5:</label>
                    <input type="text" name="head5" id="" class="form-control"  >
                   </div>
                   <div class="mb-3">
                    <label for="" class="form-label">Paragraph5:</label>
                    <textarea name="para5" class="form-control"  id="" cols="30" rows="10"></textarea>
                   </div> 
                   <div class="mb-3">
                     <label for="" class="form-label">image5:</label>
                     <input type="file" name="img5" id="" class="form-control" >
                    </div> 
            <center> <button type="submit" value="submit" class="btn btn-lg btn-light">Submit</button> </center>
         </form>
        </div>
        <br><br>
        <h1 class="text-light text-center">Interview Article</h1>
<div class="table-responsive">
    <table class="table table-bordered table-striped table-hover bg-light text-dark">
      <thead>
        <tr>
          <th>Id</th>
          <th>Heading</th>
          <th>SubHeading1</th>
          <th>SubHeading2</th>
          <th>SubHeading3</th>
          <th>SubHeading4</th>
          <th>SubHeading5</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td class="text-dark"><?php echo e($data->id); ?></td>
          <td class="text-dark"><?php echo e($data->heading); ?></td>
          <td class="text-dark"><?php echo e($data->subheading1); ?></td>
          <td class="text-dark"><?php echo e($data->subheading2); ?></td>
          <td class="text-dark"><?php echo e($data->subheading3); ?></td>
          <td class="text-dark"><?php echo e($data->subheading4); ?></td>
          <td class="text-dark"><?php echo e($data->subheading5); ?></td>
          <td><a class="del-btn mb-5" href="<?php echo e(url('/deleteinterview',$data->id)); ?>">Delete</a><br><br>
              <a class="del-btn mt-5" href="<?php echo e(url('/updateinterview',$data->id)); ?>">Edit</a></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
      
</div>
</div>
</body>
</html>

<?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/admin/interview.blade.php ENDPATH**/ ?>