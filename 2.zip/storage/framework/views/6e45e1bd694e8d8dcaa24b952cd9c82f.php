<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="contact-heading text-center">
                    CONTACT
                </h2>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="contact-text">
                  <p> <i class="fas fa-mobile-alt f-color"></i> <i class="fab fa-whatsapp f-w-color"></i>+222 42 17 17 17</p>
                  <p> <i class="fas fa-mobile-alt f-color"></i> +222 22 23 33 20</p>
                  <p> <i class="fas fa-phone fa-rotate-90"></i>  +222 45 29 24 13</p>
                  <p class="contact-email1"><i class="fas fa-envelope f-color"></i> contact@rimtic.com</p>
                  <p class="contact-email2"><i class="fas fa-envelope f-color"></i> rimtic1@gmail.com</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="contact-text">
                    <p>  <i class="fas fa-map-marker-alt f-m-color"></i></p>
                   <p class="contact-address">Tevregh Zyna<br>
                    NOT 273, Nouakchott, Mauritania</p>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
              <div class="google-map">
                <iframe width="100%" height="300" id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d30340.963190868682!2d-16.02409782429913!3d18.089119610334436!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xe964dbe747180ef%3A0x644277e325c4fb55!2sCOMPUTERS%20CENTER!5e0!3m2!1sen!2s!4v1598954718106!5m2!1sen!2s" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
              </div>
            </div>
        </div>
    </div>
    <div class="container">
       <div class="row">
          <div class="col-md-12">
                <p class="copyright">Copyright 2018, RIMTIC, Tous droits réservés ©</p>
          </div>
       </div>
    </div>
</body>
</html>
<?php /**PATH D:\xampp1\htdocs\rimtic\resources\views/contact.blade.php ENDPATH**/ ?>