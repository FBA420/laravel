
    <div id="imageCarousel" class="carousel slide" data-bs-ride="carousel">       
        <!-- Slides -->
        <div class="carousel-inner container">
            <!-- Slide 1 -->
            <div class="carousel-item active">
                <div class="row">
                    <div class="col-md-2">
                        <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" class="d-block w-100" alt="Image 1">
                    </div>
                    <div class="col-md-2">
                        <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" class="d-block w-100" alt="Image 2">
                    </div>
                    <div class="col-md-2">
                        <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" class="d-block w-100" alt="Image 3">
                    </div>
                    <div class="col-md-2">
                        <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" class="d-block w-100" alt="Image 4">
                    </div>
                    <div class="col-md-2">
                        <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" class="d-block w-100" alt="Image 5">
                    </div>
                    <div class="col-md-2">
                        <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" class="d-block w-100" alt="Image 6">
                    </div>
                </div>
            </div>
            <!-- Slide 2 -->
            <div class="carousel-item">
                <div class="row">
                    <div class="col-md-2">
                        <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" class="d-block w-100" alt="Image 7">
                    </div>
                    <div class="col-md-2">
                        <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" class="d-block w-100" alt="Image 8">
                    </div>
                    <div class="col-md-2">
                        <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" class="d-block w-100" alt="Image 9">
                    </div>
                    <div class="col-md-2">
                        <img src="<?php echo e(asset('images/logo1.jpeg')); ?>" class="d-block w-100" alt="Image 10">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
      <div class="row">
         <div class="col-md-12">
               <p class="copyright">Copyright 2018, RIMTIC, Tous droits réservés ©</p>
         </div>
      </div>
   </div>
    <!-- Bootstrap JS -->
   
    <script>
        const carousel = new bootstrap.Carousel(document.querySelector('#imageCarousel'), {
            interval: 1000 // Slide interval in milliseconds (10 seconds)
        });
    </script>
</body>
</html><?php /**PATH D:\xampp1\htdocs\rimtic\resources\views/footer.blade.php ENDPATH**/ ?>