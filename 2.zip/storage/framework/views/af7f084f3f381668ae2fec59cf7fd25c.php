<div id="imageCarousel" class="carousel slide" data-bs-ride="carousel">       
    <!-- Slides -->
    <div class="carousel-inner container">
        <!-- Slide 1 -->
        <div class="carousel-item active">
            <div class="row">
                <?php $__currentLoopData = $foot2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foot2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-2 col-6">
                    <img src="/images/<?php echo e($foot2->image); ?>" class="d-block w-100" alt="Image 1">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- Slide 2 -->
        <div class="carousel-item">
            <div class="row">
                <?php $__currentLoopData = $foot3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foot3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-2 col-6">
                    <img src="/images/<?php echo e($foot3->image); ?>" class="d-block w-100" alt="Image 7">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS -->
<script>
    const carousel = new bootstrap.Carousel(document.querySelector('#imageCarousel'), {
        interval: 1000 // Slide interval in milliseconds (10 seconds)
    });
</script>

<?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/footerslider.blade.php ENDPATH**/ ?>