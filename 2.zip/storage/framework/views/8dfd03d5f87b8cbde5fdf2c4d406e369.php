<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <div class="c-l-heading">
                <h5>
                    <?php echo e(__('welcome.Succeed in your interview')); ?>

                </h5>
            </div>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="interview-parent" onclick="toggleDiv(this)">
            <h6><i class="fas fa-check-circle"></i>
                <?php echo e($data->heading); ?>  <i class="fas fa-caret-down"></i></h6>
            </div>
            <div class="interview-child">
                <h5><?php echo e($data->heading); ?></h5>
                <div class="row mt-3">
                    <div class="col-md-8"><h6><?php echo e($data->subheading1); ?></h6>
                    <p><?php echo e($data->paragraph1); ?></p>
                    </div>
                    <div class="col-md-4">
                        <img src="/images/<?php echo e($data->image1); ?>" width="100%" height="100%" alt="pic">
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-8"><h6><?php echo e($data->subheading2); ?></h6>
                    <p><?php echo e($data->paragraph2); ?></p>
                    </div>
                    <div class="col-md-4">
                        <img src="/images/<?php echo e($data->image2); ?>" width="100%" height="100%" alt="pic">
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-8"><h6><?php echo e($data->subheading3); ?></h6>
                    <p><?php echo e($data->paragraph3); ?></p>
                    </div>
                    <div class="col-md-4">
                        <img src="/images/<?php echo e($data->image3); ?>" width="100%" height="100%" alt="pic">
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-8"><h6><?php echo e($data->subheading4); ?></h6>
                    <p><?php echo e($data->paragraph4); ?></p>
                    </div>
                    <div class="col-md-4">
                        <img src="/images/<?php echo e($data->image4); ?>" width="100%" height="100%" alt="pic">
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-8"><h6><?php echo e($data->subheading5); ?></h6>
                    <p><?php echo e($data->paragraph5); ?></p>
                    </div>
                    <div class="col-md-4">
                        <img src="/images/<?php echo e($data->image5); ?>" width="100%" height="100%" alt="pic">
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
 </div>
<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 <script>
    function toggleDiv(element) {
      var childDiv = element.nextElementSibling;
      childDiv.style.display = childDiv.style.display === 'none' ? 'block' : 'none';
    }
  </script><?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/inter.blade.php ENDPATH**/ ?>