<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
  <div class="bg-dark text-center p-4 admin-h"><h1 class="admin-h">ADMIN DASHBOARD</h1></div>
   <div class="main-div">
  <div class="sidebar">
    <?php echo $__env->make('admin.admindb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
   <!-- Page content -->
<div class="content">
  <div class="col md-8 text-light bg-dark p-4">
    <h3 class="text-center">Update Header</h3>
     <form action="<?php echo e(url('/editfooter',$data->id)); ?>" method="post" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
         <div class="mb-3">
          <label for="" class="form-label">Logo</label>
          <input type="file" name="logo" id="" class="form-control" >
         </div> 
        <div class="mb-3">
         <label for="" class="form-label">ADD</label>
         <input type="file" name="add" id="" class="form-control" >
        </div> 
        <center><button type="submit" value="submit" class="btn btn-lg btn-light">Update</button> </center>
     </form>
    </div>
</div>
</div>
</body>
</html>

<?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/admin/updateheader.blade.php ENDPATH**/ ?>