<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>

<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('admin.adminheader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<body>
  <div class="bg-dark text-center p-4 admin-h"><h1 class="admin-h">ADMIN DASHBOARD</h1></div>
   <div class="main-div">
  <div class="sidebar">
    <?php echo $__env->make('admin.admindb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>
   <!-- Page content -->
<div class="content">
  <div class="col md-8 text-light bg-dark p-4">
    <h3 class="text-center">Enter Contact Information</h3>
     <form action="<?php echo e(url('/uploadinformation')); ?>" method="post" enctype="multipart/form-data">
         <?php echo csrf_field(); ?>
         <div class="mb-3">
          <label for="" class="form-label">Address:</label>
          <input type="text" name="address" id="" class="form-control"  >
        </div>
        <div class="mb-3">
          <label for="" class="form-label">Heading</label>
          <input type="text" name="heading" id="" class="form-control"  >
         </div>
        <div class="mb-3">
         <label for="" class="form-label">Contact Number:</label>
         <input type="telephone" name="phone" id="" class="form-control"  >
        </div>
        <div class="mb-3">
         <label for="" class="form-label">Mail</label>
         <input type="email" name="email" id="" class="form-control" >
        </div> 
        <div class="mb-3">
            <label for="" class="form-label">Name</label>
            <input type="text" name="name" id="" class="form-control" >
           </div> 
        <center> <button type="submit" value="submit" class="btn btn-lg btn-light">Submit</button> </center>
     </form>
    </div>
    <h1 class="text-light text-center">Contact Information</h1>
    <div class="table-responsive">
        <table class="table table-bordered table-striped table-hover bg-light text-dark">
          <thead>
            <tr>
              <th>Id</th>
              <th>Address</th>
              <th>Mail</th>
              <th>Contact</th>
              <th>Name</th>
              <th>Heading</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td class="text-dark"><?php echo e($data->id); ?></td>
              <td class="text-dark"><?php echo e($data->address); ?></td>
              <td class="text-dark"><?php echo e($data->mail); ?></td>
              <td class="text-dark"><?php echo e($data->contact); ?></td>
              <td class="text-dark"><?php echo e($data->name); ?></td>
              <td class="text-dark"><?php echo e($data->heading); ?></td>
              <td><a class="del-btn mb-5" href="<?php echo e(url('/deleteinformation',$data->id)); ?>">Delete</a><br><br>
                  <a class="del-btn mt-5" href="<?php echo e(url('/updateinformation',$data->id)); ?>">Edit</a></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
      
</div>
</div>
</body>
</html>

<?php echo $__env->make('admin.adminfooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/admin/information.blade.php ENDPATH**/ ?>