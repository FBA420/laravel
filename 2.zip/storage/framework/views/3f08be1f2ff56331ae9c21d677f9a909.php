<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
     <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="c-l-heading">
                    <h5><?php echo e(__('welcome.CV templates to download')); ?></h5>
                </div>
            </div>
        </div>
     </div>
     <div class="container">
        <div class="row">
   <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <div class="col-md-3">
      <p  class="cv-name"><?php echo e($data3->name); ?></p>
      <center><a href="/pdffiles/<?php echo e($data3->cvfile); ?>" download>
        <img src="/pdffiles/<?php echo e($data3->cvimage); ?>" width="250px" class="cv-img" height="300px"><br><br>
         </a></center>
     </div>    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
     </div>
     <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/cv.blade.php ENDPATH**/ ?>