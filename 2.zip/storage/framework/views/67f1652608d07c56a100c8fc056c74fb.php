
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php if(Session::has('success')): ?>
    <div class="alert alert-success text-center">
        <?php echo e(Session::get('success')); ?>

    </div>
<?php endif; ?>
<div class="container">
    <button type="button" disabled="" class="btn btn-dark btn-lg btn-block fontAlmari btn btn-primary"
    style="margin-top: 15px; margin-bottom: 10px; color: rgb(255, 255, 255); width: 100%;">
    <?php echo e(__('welcome.You can send your opinions about us')); ?>

    <span style="font-weight: bold;">contact@rimemploi.com</span>
</button>  
          <!-- row having bottom and top lines -->
    <div>
        <p class="fontAlmari" style="border-width: 2px 0px; border-top-style: solid; border-right-style: initial; border-bottom-style: solid; border-left-style: initial; border-color: black; border-image: initial; text-align: center; font-size: 25px; padding: 5px;">
        <?php echo e(__('welcome.Submit a job offer')); ?></p>
    </div>
</div>
<div class="container">
    <form action="<?php echo e(url('/joboffer')); ?>" method="post" enctype="multipart/form-data">
 <?php echo csrf_field(); ?>
<div>
    <div class="row" style="margin: 15px 1px 0px; background: rgb(238, 238, 238); padding-bottom: 10px;">
    <div class="col-sm-4 col-12">
        <label class="fontAlmari form-label"><?php echo e(__('welcome.Company')); ?></label>
        <input required type="text" hidden="" value="0">
        <input required type="text" name="company" class="form-control">
        <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
    </div>
    <div class="col-sm-4 col-12">
        <label class="fontAlmari form-label"><?php echo e(__('welcome.Logo')); ?></label>
        <input required type="file" name="logo"  class="form-control">
    </div>
    <div class="col-sm-4 col-12">
        <label class="fontAlmari form-label"><?php echo e(__('welcome.City')); ?></label>
        <input required type="text" name="city"  class="form-control" value="">
        <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
    </div>
    </div>
    <div class="row" style="margin: 10px 0px 5px;">
<div class="col-sm-9 col-12">
    <label class="fontAlmari form-label"><?php echo e(__('welcome.Title')); ?></label>
    <input required type="text" name="title"  class="form-control">
    <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
</div>
<div class="col-sm-3 col-12">
    <label class="fontAlmari form-label"><?php echo e(__('welcome.Application deadline')); ?></label>
    <input required type="date" name="deadline"  class="form-control">
    <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
</div>

<div class="col-sm-12 col-12">
    <label class="fontAlmari form-label"><?php echo e(__('welcome.Description')); ?></label>
    <textarea class="form-control" name="description" id="" cols="30" rows="10"></textarea>
    <script>
    tinymce.init({
      selector: 'textarea',
      plugins: 'anchor autolink charmap codesample emoticons image link lists media searchreplace table visualblocks wordcount checklist mediaembed casechange export formatpainter pageembed linkchecker a11ychecker tinymcespellchecker permanentpen powerpaste advtable advcode editimage tinycomments tableofcontents footnotes mergetags autocorrect typography inlinecss',
      toolbar: 'undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | link image media table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | align lineheight | checklist numlist bullist indent outdent | emoticons charmap | removeformat',
      tinycomments_mode: 'embedded',
      tinycomments_author: 'Author name',
      mergetags_list: [
        { value: 'First.Name', title: 'First Name' },
        { value: 'Email', title: 'Email' },
      ]
    });
  </script>
    
</div>
<div class="col-sm-12 col-12" style="margin-top: 50px;">
 <div class="row">
 <div class="col-sm-12 col-12" style="margin: 10px 0px 5px;">
 <p class="fontAlmari" style="font-weight: bold; color: black;"><?php echo e(__('welcome.Other information')); ?>: </p>
 </div>
 <div class="col-lg-4 col-12">
 <label class="fontAlmari form-label"><?php echo e(__('welcome.Domain')); ?></label>
 <select name="domaine" aria-label="Default select example" class="fontAlmari form-select">
 <option name="domaine" value=""></option>
 <option name="domaine" value="Others"><?php echo e(__('welcome.Others')); ?></option>
 <option name="domaine" value="ressource"><?php echo e(__('welcome.Human ressources')); ?></option>
 <option name="domaine" value="Commercial"><?php echo e(__('welcome.Commercial, capital-risque, marketing')); ?></option>
 <option name="domaine" value="Information"><?php echo e(__('welcome.Computing and Information Technology')); ?></option>
 <option name="domaine" value="transport"><?php echo e(__('welcome.Logistic transport')); ?></option>
 <option name="domaine" value="Maintenance"><?php echo e(__('welcome.Maintenance and Repair')); ?></option>
 <option name="domaine" value="Tourism"><?php echo e(__('welcome.Tourism, hotels, restaurants')); ?></option>
 <option name="domaine" value="Management"><?php echo e(__('welcome.Management, Finance, Accounting')); ?></option>
 <option name="domaine" value="Environment"><?php echo e(__('welcome.Environment and Sustainable Development')); ?></option>
 <option name="domaine" value="Security"><?php echo e(__('welcome.Security')); ?></option>
 <option name="domaine" value="Health"><?php echo e(__('welcome.Health and social')); ?></option>
 <option name="domaine" value="Secretariat"><?php echo e(__('welcome.Secretariat, assistant')); ?></option>
 <option name="domaine" value="Nutrition"><?php echo e(__('welcome.Nutrition, Breeding, Agriculture')); ?></option>
 <option name="domaine" value="Languages"><?php echo e(__('welcome.Languages, Translation, Literary')); ?></option>
 <option name="domaine" value="Electricity_Energy"><?php echo e(__('welcome.Electricity, Energy, Mechanics, Automation')); ?></option>
 <option name="domaine" value="che_bio"><?php echo e(__('welcome.Chemistry, Biology')); ?></option>
 <option name="domaine" value="Civil_Engineering"><?php echo e(__('welcome.Civil Engineering, Construction')); ?></option>
 <option name="domaine" value="Bank"><?php echo e(__('welcome.Bank and insurance')); ?></option>
 </select>
 <p class="fontAlmari" style="font-size: 12px; color: red;">
 </p>
 </div>
 <div class="col-lg-4 col-12">
 <label class="fontAlmari form-label"><?php echo e(__('welcome.Level of study requested')); ?></label>
 <select name="qualification" aria-label="Default select example" class="fontAlmari form-select">
 <option name="qualification" value=""></option>
 <option name="qualification" value="Without"><?php echo e(__('welcome.Without')); ?></option>
 <option name="qualification" value="Primary"><?php echo e(__('welcome.Primary')); ?></option>
 <option name="qualification" value="brevet"><?php echo e(__('welcome.patent')); ?></option>
 <option name="qualification" value="Bac">Bac</option>
 <option name="qualification" value="Bac_2">Bac+2</option>
 <option name="qualification" value="Bac_3">Bac+3</option>
 <option name="qualification" value="Bac_4">Bac+4</option>
 <option name="qualification" value="Bac_5">Bac+5</option>
 <option name="qualification" value="PhD"><?php echo e(__('welcome.PhD')); ?></option>
 <option name="qualification" value="Other"><?php echo e(__('welcome.Other')); ?></option>
 </select>
 <p class="fontAlmari" style="font-size: 12px; color: red;"></p>
 </div>
 <div class="col-lg-4 col-12">
 <label class="fontAlmari form-label"><?php echo e(__('welcome. Years of Experience')); ?></label>
 <select name="experience" aria-label="Default select example" class="fontAlmari form-select">
    <option value=""></option>
    <option name="experience" value="-">-</option>
    <option name="experience" value="0">0</option>
    <option name="experience"  value="1">1</option>
    <option name="experience" value="2">2</option>
    <option name="experience" value="3">3</option>
    <option name="experience" value="4">4</option>
    <option name="experience" value="5">5</option>
    <option name="experience" value="6">6</option>
    <option name="experience" value="7">7</option>
    <option name="experience" value="8">8</option>
    <option name="experience" value="9">9</option>
    <option name="experience" value="10">10</option>
    <option name="experience" value="11">11</option>
    <option name="experience" value="12">12</option>
    <option name="experience" value="13">13</option>
    <option name="experience" value="14">14</option>
    <option name="experience" value="15">15</option>
</select>
<p class="fontAlmari" style="font-size: 12px; color: red;"></p>
</div>
</div>
</div>
</div>
 <table class="table">
    <tbody>
        <tr>
            <td style="width: 80%;">
            <input  type="file" name="file" class="form-control"> 
        </td>
        <td>
 <button type="button" class="btn btn-success fontAlmari btn btn-primary" style="background: none; color: black; width: 80%;"> <?php echo e(__('welcome.Other files')); ?></button>
</td>
</tr>
</tbody>
</table>
<div style="text-align: center;">
 <button type="submit" value="submit" class="btn btn-success fontAlmari btn btn-primary" style="width: 190px; background: green; color: rgb(255, 255, 255);"><?php echo e(__('welcome.To validate')); ?></button>
    </div>
</div>


    </form>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/jobform1.blade.php ENDPATH**/ ?>