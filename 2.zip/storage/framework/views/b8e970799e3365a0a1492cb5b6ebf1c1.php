<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <?php echo $__env->make('css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
</head>
<style>
    .btn{
        font-size: .9em;
        border-radius: 1px;
        letter-spacing: 2px;
        border: 1px solid #067106;
        background: #067106;
        color: #fff;
    }
    .form-container {
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2); 
        padding: 40px;
        background-color: white;
    }
    .form-control {
    padding: 20px; 
  }
  .form-label {
    padding-top: 40px;
    padding-bottom: 10px;
  }
    label {
        font-weight: 900;
        margin: 10px;
    }
    input {
        padding: 30px;
    }
    /* section {
    padding-top: 4rem;
    padding-bottom: 5rem;
    background-color:#f5f6f9;
} */

</style>
<body style="background-color: #FBFDFE;">
<section>

</section>
</body>
</html>


<div style="margin-top: 20px;">
  <link rel="stylesheet" href="#" type="text/css">
  <div id="section" class="signup">
    <div class="container">
      <div class="row bg-light">
        <div class="col-sm-12">
          <center>
            <h3 style="font-weight: 900; padding: 10px;">Inscrivez vous et gérer votre CV</h3>
          </center>
        </div>
      </div>
      <div class="signup-content">
        <form action="#" method="POST" enctype="multipart/form-data" id="signup-form" class="signup-form">
          <input type="hidden" name="_token" value="uxNJWbss40zXG31jngxoemakkzCDf6RwMZXB9MWg">
          <div class="row">
            <div class="col-sm-6">
              <label for="city">Civilite</label>
              <div class="select-list">
                <select name="civilite" id="city" class="form-control form-input">
                  <option value="Mr">Mr</option>
                  <option value="Mme">Mme</option>
                  <option value="Mlle">Mlle</option>
                </select>
              </div>
            </div>
            <div class="form-group col-sm-6">
              <label for="phone_number">Telephone</label>
              <input type="number" class="form-input" name="telephone" id="phone_number">
            </div>
            <div class="form-group col-sm-12">
              <label for="last_name">Nom</label>
              <input type="text" class="form-input" name="nom" id="last_name" required="">
            </div>
            <div class="form-group col-sm-6">
              <label for="phone_number">EMAIL</label>
              <input type="email" required="" name="email" class="form-input" id="phone_number">
            </div>
            <div class="form-group col-sm-6">
              <label for="password">Password</label>
              <input type="password" required="" name="password" class="form-input" id="password">
            </div>
            <div class="form-group col-sm-12">
              <button type="submit" class="btn" style="border-radius: 25px; float: right; font-weight: 900;">S'Inscrire</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<script src="script.js"></script>
</div>
</body>
</html><?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/forms.blade.php ENDPATH**/ ?>