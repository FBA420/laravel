<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
   <div class="container-fluid mt-5">
    <div class="row">
        <div class="col-md-4 mb-3">
            <div class="form-links">
                <a href="/job-offer-form"><?php echo e(__('welcome.Submit a job offer')); ?></a>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="form-links">
                <a href="/cv-form"><?php echo e(__('welcome.Submit your resume')); ?></a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-links">
                <a href="/tender-form"><?php echo e(__('welcome.Submit a call for tenders')); ?></a>
            </div>
        </div>
    </div>
   </div>
<div class="home-data-bg">
      <div class="container-fluid">
    <div class="row">
        <div class="col-md-4">
            <div class="data-show">
                <button onclick="showContainer(1)" class="button-link"><?php echo e(__('welcome.JOB OFFERS')); ?></button>
            </div>
        </div>
        <div class="col-md-4">
            <div class="data-show">
                <button onclick="showContainer(2)" class="button-link"><?php echo e(__('welcome.CALLS FOR TENDERS')); ?></button>
            </div>
        </div>
        <div class="col-md-4">
            <div class="data-show">
                <button onclick="showContainer(3)" class="button-link"><?php echo e(__('welcome.PUBLICATIONS AND NOTICES')); ?></button>
            </div>
        </div>
    </div>
   </div>
   <div id="container1" class="data-container job-box">
   <div class="container-fluid">
    <div class="row">
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 jobs-container">
           <div class="job-offer-div">
              <div class="job-img">
                <img src="/images/<?php echo e($data->logo); ?>" width="100%" height="auto" alt="">
             </div>
             <div class="job-text">
              <a href="<?php echo e(url('/job-description', $data->id)); ?>"><?php echo e($data->title); ?></a>
                <div class="job-info">
                    <p><i class="fas fa-map-marker-alt job-l-color"></i> <span class="job-location"><?php echo e($data->city); ?></span>
                     <i class="fas fa-eye job-l-color eye"></i> <span class="job-views"><?php echo e($data->views); ?></span>
                   <i class="fas fa-clock fa-spin fa-xs f-clock-color"></i> <span class="job-date f-clock-color"><?php echo e($data->deadline); ?></span></p>
                </div>
                <div class="container-j">
                    <div class="content">
                      <p><i class="fas fa-building fa-xs f-b-color"></i><?php echo e($data->company); ?></p>
                    </div>
                    <div class="button-toggle">
                      <button onclick="toggleContent(<?php echo e($index); ?>)"  class="btn-togle"><i class="fas fa-bars toggle-icon"></i></button>
                    </div>
                  </div>
                  <div id="toggleDiv<?php echo e($index); ?>" class="toggle-content">
                    <div class="toggle-container">
                        <div class="toggle-text">
                          <p class="t-font">
                            <span class="rounded-circle ft-p">
                              <i class="fas fa-chevron-right text-white ft-p-i"></i>
                            </span>
                            <?php echo e($data->domain); ?></p>
                        </div>
                        <div class="toggle-text">
                          <p class="t-font">
                            <span class="rounded-circle ft-p">
                              <i class="fas fa-chevron-right text-white ft-p-i"></i>
                            </span>
                            <?php echo e($data->qualification); ?></p>
                        </div>
                        <div class="toggle-text">
                          <p class="t-font">
                            <span class="rounded-circle ft-p">
                              <i class="fas fa-chevron-right text-white ft-p-i"></i>
                            </span>
                            <?php echo e($data->experience); ?></p>
                        </div>
                    </div>
                  </div>
             </div>
           </div>
          </div>
          
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
   </div>
   </div>
   <div id="container2" class="data-container job-box">
    <div class="container-fluid">
      <div class="row">
      <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 jobs-container">
             <div class="job-offer-div">
                <div class="job-img">
                  <img src="/images/<?php echo e($data1->logo); ?>" width="100%" height="auto" alt="">
               </div>
               <div class="job-text">
                <a href="<?php echo e(url('/tenders-description', $data1->id)); ?>"><?php echo e($data1->title); ?></a>
                  <div class="job-info">
                    <p><i class="fas fa-map-marker-alt job-l-color"></i> <span class="job-location"><?php echo e($data1->city); ?></span>
                      <i class="fas fa-eye job-l-color eye"></i> <span class="job-views"><?php echo e($data1->views); ?></span>
                    <i class="fas fa-clock fa-spin fa-xs f-clock-color"></i> <span class="job-date f-clock-color"><?php echo e($data1->deadline); ?></span></p>
                </div>
                  <div class="container-j">
                      <div class="content">
                        <p><i class="fas fa-building fa-xs f-b-color"></i><?php echo e($data1->company); ?></p>
                      </div>
                    </div>
               </div>
             </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
     </div>
   </div>
  </div>
   <div id="container3" class="data-container job-box">
    <div class="container-fluid">
      <div class="row">
      <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-md-4 jobs-container">
             <div class="job-offer-div">
                <div class="job-img">
                  <img src="/images/<?php echo e($data2->logo); ?>" width="100%" height="auto" alt="">
               </div>
               <div class="job-text">
                <a href="<?php echo e(url('/reviews-description', $data2->id)); ?>"><?php echo e($data2->title); ?></a>
                  <div class="job-info">
                    <p class="">
                      <i class="fas fa-eye job-l-color eye ml"></i> <span class="job-views"><?php echo e($data2->views); ?></span>
                    <i class="fas fa-clock fa-spin fa-xs f-clock-color"></i> <span class="job-date f-clock-color"><?php echo e($data2->deadline); ?></span></p>
                  </div>
                  <div class="container-j">
                      <div class="content">
                        <p><i class="fas fa-building fa-xs f-b-color"></i><?php echo e($data2->company); ?></p>
                      </div>
                  </div>
               </div>
             </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
     </div>
   </div>
  </div>
  <div class="home-data-bg pt-3">
   <div class="container-fluid">
    <div class="row">
        <div class="col-md-4 mb-3">
            <div class="form-links">
                <a href="/cv"><?php echo e(__('welcome.CV templates to download')); ?></a>
            </div>
        </div>
        <div class="col-md-4 mb-3">
            <div class="form-links">
                <a href="/letter"><?php echo e(__('welcome.Cover letter templates to download')); ?></a>
            </div>
        </div>
        <div class="col-md-4">
            <div class="form-links">
                <a href="/interview-article"><?php echo e(__('welcome.Succeed in your interview')); ?></a>
            </div>
        </div>
    </div>
  </div>
  <div class="container-fluid">
    <div class="row">
      <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4">
         <div class="cvs-container">
          <div class="cvs-img">
            <img src="/images/<?php echo e($data3->image); ?>" width="100%" height="100%" alt="">
          </div>
          <div class="cvs-text">
            <h6><?php echo e(__('welcome.Study level')); ?>: <span class="cv-t-s">XXXXXXX</span></h6>
            <h6>
            <?php echo e(__('welcome.Field of Study')); ?>: <span class="cv-t-s">XXXXXXX </span>
            </h6>
            <h6>
            <?php echo e(__('welcome.AGE')); ?>: <span class="cv-t-s"> XXXXXXX</span>
            </h6>
            <h6>
            <?php echo e(__('welcome.NAME')); ?>: <span class="cv-t-s">XXXXXXX
              </span></h6>
            <h6>
            <?php echo e(__('welcome.Contact')); ?>:<span class="cv-t-s">XXXXXXX</span>
            </h6>
          </div>
         </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
</div>
<div>

  <div id="imageCarousel" class="carousel slide mt-5 mb-5" data-bs-ride="carousel">       
    <!-- Slides -->
    <div class="carousel-inner container">
      <?php $__currentLoopData = $ade; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ade): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <!-- Slide 1 -->
        <div class="carousel-item active">
            <div class="row">
              <div class="col-md-2"></div>
                <div class="col-md-8">
                  <center>  <img src="/images/<?php echo e($ade->image); ?>" class="d-block w-100" alt="Image 1"></center>
                </div>      
              <div class="col-md-2"></div>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Slide 2 -->
    </div>
</div>
   <?php echo $__env->make('footerslider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
   <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

   <script>
    function toggleContent(index) {
      var toggleDiv = document.getElementById('toggleDiv' + index);
      toggleDiv.classList.toggle('show');
    }
  </script>
  
  
  <script>
    function showContainer(containerNumber) {
      // Hide all containers
      var containers = document.getElementsByClassName('data-container');
      for (var i = 0; i < containers.length; i++) {
        containers[i].style.display = 'none';
      }

      // Show the selected container
      var container = document.getElementById('container' + containerNumber);
      container.style.display = 'block';
    }
  </script>

<?php /**PATH D:\xampp1\htdocs\rimemploi\resources\views/home.blade.php ENDPATH**/ ?>